# ARMAN APP STORE - Android (Kotlin)
Phase 1: minimal native app used to prove the cloud build works. Built with GitHub Actions.
