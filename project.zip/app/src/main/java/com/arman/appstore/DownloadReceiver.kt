package com.arman.appstore

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.arman.appstore.data.AppState
import com.arman.appstore.data.Downloads
import com.arman.appstore.data.InstallQueue
import com.arman.appstore.data.Notifier

class DownloadReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        if (id < 0 || !Downloads.isOurs(ctx, id)) return
        Downloads.forget(ctx, id)
        val dm = ctx.getSystemService(DownloadManager::class.java) ?: return
        var path: String? = null
        dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
            if (c.moveToFirst() &&
                c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL
            ) {
                path = Uri.parse(c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))).path
            }
        }
        val p = path ?: return
        InstallQueue.add(ctx, p)
        if (AppState.foreground) InstallQueue.launchNext(ctx) else Notifier.installReady(ctx, InstallQueue.size(ctx))
    }
}
