package com.arman.appstore

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import com.arman.appstore.data.AppState
import com.arman.appstore.data.DownloadCenter
import com.arman.appstore.data.Notifier

/** Receives the real result of an installation from Android. */
class InstallStatusReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        val pkg = intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME) ?: intent.getStringExtra("pkg") ?: ""
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (AppState.foreground) ctx.startActivity(confirm) else Notifier.confirmInstall(ctx, confirm)
                }
            }
            PackageInstaller.STATUS_SUCCESS -> DownloadCenter.onInstallResult(pkg, true, "")
            else -> DownloadCenter.onInstallResult(pkg, false, failureCode(status, msg))
        }
    }

    private fun failureCode(status: Int, msg: String): String = when {
        msg.contains("VERSION_DOWNGRADE", true) -> "downgrade"
        msg.contains("UPDATE_INCOMPATIBLE", true) || msg.contains("signatures do not match", true) -> "signature"
        status == PackageInstaller.STATUS_FAILURE_CONFLICT -> "signature"
        status == PackageInstaller.STATUS_FAILURE_ABORTED -> "cancelled"
        status == PackageInstaller.STATUS_FAILURE_STORAGE -> "storage"
        status == PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> "incompatible"
        status == PackageInstaller.STATUS_FAILURE_INVALID -> "bad_apk"
        status == PackageInstaller.STATUS_FAILURE_BLOCKED -> "blocked"
        else -> "failed"
    }
}
