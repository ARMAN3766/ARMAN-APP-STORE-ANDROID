package com.arman.appstore

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.arman.appstore.data.AppState
import com.arman.appstore.data.Downloads
import com.arman.appstore.data.InstallQueue
import com.arman.appstore.ui.AppRoot
import com.arman.appstore.ui.ArmanTheme
import com.arman.appstore.ui.StoreViewModel

class MainActivity : ComponentActivity() {
    private val vm: StoreViewModel by viewModels()

    override fun onResume() {
        super.onResume()
        AppState.foreground = true
        vm.refreshInstalled()
        if (InstallQueue.size(this) > 0) InstallQueue.launchNext(this)
    }

    override fun onPause() {
        super.onPause()
        AppState.foreground = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Downloads.cleanup(this)
        setContent {
            ArmanTheme(vm.themeMode) {
                AppRoot(vm)
            }
        }
    }
}
