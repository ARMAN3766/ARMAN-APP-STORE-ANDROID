package com.arman.appstore

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.arman.appstore.ui.AppRoot
import com.arman.appstore.ui.ArmanTheme
import com.arman.appstore.ui.StoreViewModel

class MainActivity : ComponentActivity() {
    private val vm: StoreViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArmanTheme {
                AppRoot(vm)
            }
        }
    }
}
