package com.arman.appstore.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiException(message: String, val code: Int) : Exception(message)

private fun JSONObject.str(key: String): String? = if (isNull(key)) null else optString(key)

object Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json".toMediaType()

    private fun errorText(body: String, code: Int): String {
        return try {
            val j = JSONObject(body)
            j.str("msg") ?: j.str("error_description") ?: j.str("message") ?: j.str("error") ?: "HTTP $code"
        } catch (e: Exception) {
            "HTTP $code"
        }
    }

    private fun call(method: String, path: String, body: JSONObject? = null, token: String? = null): String {
        val b = Request.Builder()
            .url(Config.SUPABASE_URL + path)
            .header("apikey", Config.SUPABASE_KEY)
        if (token != null) b.header("Authorization", "Bearer $token")
        if (method == "POST") b.post((body?.toString() ?: "{}").toRequestBody(jsonType)) else b.get()
        client.newCall(b.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException(errorText(text, r.code), r.code)
            return text
        }
    }

    private fun parseSession(j: JSONObject): UserSession {
        val user = j.getJSONObject("user")
        val expires = if (j.has("expires_at")) j.getLong("expires_at")
        else System.currentTimeMillis() / 1000 + j.optLong("expires_in", 3600)
        return UserSession(
            accessToken = j.getString("access_token"),
            refreshToken = j.getString("refresh_token"),
            expiresAtSec = expires,
            userId = user.getString("id"),
            email = user.optString("email", "")
        )
    }

    suspend fun signIn(email: String, password: String): UserSession = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password)
        parseSession(JSONObject(call("POST", "/auth/v1/token?grant_type=password", body)))
    }

    /** Returns null when the server wants email confirmation first. */
    suspend fun signUp(email: String, password: String): UserSession? = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password)
        val j = JSONObject(call("POST", "/auth/v1/signup", body))
        if (j.has("access_token")) parseSession(j) else null
    }

    suspend fun refresh(refreshToken: String): UserSession = withContext(Dispatchers.IO) {
        val body = JSONObject().put("refresh_token", refreshToken)
        parseSession(JSONObject(call("POST", "/auth/v1/token?grant_type=refresh_token", body)))
    }

    suspend fun fetchProfile(token: String, s: UserSession): Profile = withContext(Dispatchers.IO) {
        val arr = JSONArray(call("GET", "/rest/v1/profiles?id=eq.${s.userId}&select=email,role", token = token))
        if (arr.length() == 0) Profile(s.email, "user")
        else {
            val o = arr.getJSONObject(0)
            Profile(o.str("email") ?: s.email, o.str("role") ?: "user")
        }
    }

    suspend fun fetchApps(token: String): List<StoreApp> = withContext(Dispatchers.IO) {
        val path = "/rest/v1/apps?select=id,name,developer,category,description,icon_url,updated_at," +
            "app_versions(version_name,apk_url,size_bytes,changelog,created_at)" +
            "&is_published=eq.true&order=updated_at.desc"
        val arr = JSONArray(call("GET", path, token = token))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val vs = o.optJSONArray("app_versions") ?: JSONArray()
            StoreApp(
                id = o.getString("id"),
                name = o.str("name") ?: "",
                developer = o.str("developer") ?: "",
                category = o.str("category") ?: "Tools",
                description = o.str("description") ?: "",
                iconUrl = o.str("icon_url"),
                updatedAt = o.str("updated_at") ?: "",
                versions = (0 until vs.length()).map { j ->
                    val v = vs.getJSONObject(j)
                    AppVersion(
                        versionName = v.str("version_name") ?: "",
                        apkUrl = v.str("apk_url") ?: "",
                        sizeBytes = if (v.isNull("size_bytes")) null else v.optLong("size_bytes"),
                        changelog = v.str("changelog"),
                        createdAt = v.str("created_at") ?: ""
                    )
                }
            )
        }
    }
}

class SessionStore(context: Context) {
    private val p = context.getSharedPreferences("arman_session", Context.MODE_PRIVATE)

    fun save(s: UserSession) {
        p.edit().putString("at", s.accessToken).putString("rt", s.refreshToken)
            .putLong("exp", s.expiresAtSec).putString("uid", s.userId).putString("email", s.email).apply()
    }

    fun load(): UserSession? {
        val at = p.getString("at", null) ?: return null
        val rt = p.getString("rt", null) ?: return null
        val uid = p.getString("uid", null) ?: return null
        return UserSession(at, rt, p.getLong("exp", 0), uid, p.getString("email", "") ?: "")
    }

    fun clear() {
        p.edit().remove("at").remove("rt").remove("exp").remove("uid").remove("email").apply()
    }

    fun loadBn(): Boolean = p.getBoolean("bn", true)
    fun saveBn(v: Boolean) { p.edit().putBoolean("bn", v).apply() }
}
