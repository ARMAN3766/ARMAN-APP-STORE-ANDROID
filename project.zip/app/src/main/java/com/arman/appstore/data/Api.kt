package com.arman.appstore.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import okio.BufferedSink
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.random.Random
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiException(message: String, val code: Int) : Exception(message)

private fun JSONObject.str(key: String): String? = if (isNull(key)) null else optString(key)

object Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json".toMediaType()

    private fun errorText(body: String, code: Int): String {
        return try {
            val j = JSONObject(body)
            j.str("msg") ?: j.str("error_description") ?: j.str("message") ?: j.str("error") ?: "HTTP $code"
        } catch (e: Exception) {
            "HTTP $code"
        }
    }

    private fun call(method: String, path: String, body: JSONObject? = null, token: String? = null, prefer: String? = null): String {
        val b = Request.Builder()
            .url(Config.SUPABASE_URL + path)
            .header("apikey", Config.SUPABASE_KEY)
        if (token != null) b.header("Authorization", "Bearer $token")
        if (prefer != null) b.header("Prefer", prefer)
        val rb = if (method == "GET" || method == "DELETE") null else (body?.toString() ?: "{}").toRequestBody(jsonType)
        b.method(method, rb)
        client.newCall(b.build()).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException(errorText(text, r.code), r.code)
            return text
        }
    }

    private fun parseSession(j: JSONObject): UserSession {
        val user = j.getJSONObject("user")
        val expires = if (j.has("expires_at")) j.getLong("expires_at")
        else System.currentTimeMillis() / 1000 + j.optLong("expires_in", 3600)
        return UserSession(
            accessToken = j.getString("access_token"),
            refreshToken = j.getString("refresh_token"),
            expiresAtSec = expires,
            userId = user.getString("id"),
            email = user.optString("email", "")
        )
    }

    suspend fun signIn(email: String, password: String): UserSession = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password)
        parseSession(JSONObject(call("POST", "/auth/v1/token?grant_type=password", body)))
    }

    /** Returns null when the server wants email confirmation first. */
    suspend fun signUp(email: String, password: String): UserSession? = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password)
        val j = JSONObject(call("POST", "/auth/v1/signup", body))
        if (j.has("access_token")) parseSession(j) else null
    }

    suspend fun refresh(refreshToken: String): UserSession = withContext(Dispatchers.IO) {
        val body = JSONObject().put("refresh_token", refreshToken)
        parseSession(JSONObject(call("POST", "/auth/v1/token?grant_type=refresh_token", body)))
    }

    suspend fun fetchProfile(token: String, s: UserSession): Profile = withContext(Dispatchers.IO) {
        val arr = JSONArray(call("GET", "/rest/v1/profiles?id=eq.${s.userId}&select=email,role", token = token))
        if (arr.length() == 0) Profile(s.email, "user")
        else {
            val o = arr.getJSONObject(0)
            Profile(o.str("email") ?: s.email, o.str("role") ?: "user")
        }
    }

    suspend fun fetchApps(token: String?, all: Boolean = false): List<StoreApp> = withContext(Dispatchers.IO) {
        val path = "/rest/v1/apps?select=id,name,developer,category,description,icon_url,package_name,updated_at,is_published,screenshots," +
            "app_versions(id,version_name,apk_url,size_bytes,changelog,created_at)" +
            (if (all) "" else "&is_published=eq.true") + "&order=updated_at.desc"
        val arr = JSONArray(call("GET", path, token = token))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val vs = o.optJSONArray("app_versions") ?: JSONArray()
            StoreApp(
                id = o.getString("id"),
                name = o.str("name") ?: "",
                developer = o.str("developer") ?: "",
                category = o.str("category") ?: "Tools",
                description = o.str("description") ?: "",
                iconUrl = o.str("icon_url"),
                packageName = o.str("package_name") ?: "",
                updatedAt = o.str("updated_at") ?: "",
                published = o.optBoolean("is_published", true),
                screenshots = (o.optJSONArray("screenshots")?.let { sa -> (0 until sa.length()).map { sa.getString(it) } } ?: emptyList()),
                versions = (0 until vs.length()).map { j ->
                    val v = vs.getJSONObject(j)
                    AppVersion(
                        id = v.str("id") ?: "",
                        versionName = v.str("version_name") ?: "",
                        apkUrl = v.str("apk_url") ?: "",
                        sizeBytes = if (v.isNull("size_bytes")) null else v.optLong("size_bytes"),
                        changelog = v.str("changelog"),
                        createdAt = v.str("created_at") ?: ""
                    )
                }
            )
        }
    }

    suspend fun recover(email: String) = withContext(Dispatchers.IO) {
        call("POST", "/auth/v1/recover", JSONObject().put("email", email))
        Unit
    }

    suspend fun verifyRecovery(email: String, code: String): UserSession = withContext(Dispatchers.IO) {
        val b = JSONObject().put("type", "recovery").put("email", email).put("token", code.trim())
        parseSession(JSONObject(call("POST", "/auth/v1/verify", b)))
    }

    suspend fun updatePassword(token: String, password: String) = withContext(Dispatchers.IO) {
        call("PUT", "/auth/v1/user", JSONObject().put("password", password), token)
        Unit
    }

    suspend fun signInWithGoogle(idToken: String): UserSession = withContext(Dispatchers.IO) {
        val b = JSONObject().put("provider", "google").put("id_token", idToken)
        parseSession(JSONObject(call("POST", "/auth/v1/token?grant_type=id_token", b)))
    }

    suspend fun addHistory(token: String, appId: String, versionId: String?, action: String) = withContext(Dispatchers.IO) {
        val b = JSONObject().put("app_id", appId).put("action", action)
        if (!versionId.isNullOrBlank()) b.put("version_id", versionId)
        call("POST", "/rest/v1/download_history", b, token)
        Unit
    }

    suspend fun fetchHistory(token: String): List<HistoryItem> = withContext(Dispatchers.IO) {
        val path = "/rest/v1/download_history?select=action,created_at,apps(id,name,icon_url,package_name)&order=created_at.desc&limit=100"
        val arr = JSONArray(call("GET", path, token = token))
        val out = mutableListOf<HistoryItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val a = o.optJSONObject("apps") ?: continue
            out.add(
                HistoryItem(
                    appId = a.str("id") ?: continue,
                    appName = a.str("name") ?: "",
                    iconUrl = a.str("icon_url"),
                    packageName = a.str("package_name") ?: "",
                    action = o.str("action") ?: "",
                    createdAt = o.str("created_at") ?: ""
                )
            )
        }
        out
    }

    // ---------- admin helpers (database rules allow these only for the admin role) ----------

    fun slugify(text: String): String =
        text.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "app" }

    private fun nowIso(): String {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date())
    }

    fun fileInfo(ctx: Context, uri: Uri): Pair<String, Long> {
        var name = "file"
        var size = -1L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        return name to size
    }

    private class UriBody(
        val ctx: Context, val uri: Uri, val type: MediaType, val size: Long, val onProgress: (Int) -> Unit
    ) : RequestBody() {
        override fun contentType(): MediaType = type
        override fun contentLength(): Long = size
        override fun writeTo(sink: BufferedSink) {
            val input = ctx.contentResolver.openInputStream(uri) ?: throw ApiException("cannot read file", 0)
            input.use { ins ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var last = -1
                while (true) {
                    val n = ins.read(buf)
                    if (n == -1) break
                    sink.write(buf, 0, n)
                    done += n
                    if (size > 0) {
                        val p = (done * 100 / size).toInt()
                        if (p != last) { last = p; onProgress(p) }
                    }
                }
            }
        }
    }

    /** Uploads a phone file to Supabase Storage and returns its public URL. */
    suspend fun upload(
        ctx: Context, token: String, bucket: String, path: String, uri: Uri, mime: String, size: Long, onProgress: (Int) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val body = UriBody(ctx, uri, mime.toMediaType(), size, onProgress)
        val req = Request.Builder()
            .url(Config.SUPABASE_URL + "/storage/v1/object/" + bucket + "/" + path)
            .header("apikey", Config.SUPABASE_KEY)
            .header("Authorization", "Bearer $token")
            .header("x-upsert", "true")
            .post(body)
            .build()
        val upClient = client.newBuilder().writeTimeout(180, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS).build()
        upClient.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException(errorText(text, r.code), r.code)
        }
        Config.SUPABASE_URL + "/storage/v1/object/public/" + bucket + "/" + path
    }

    suspend fun createApp(token: String, name: String, dev: String, cat: String, pkg: String, desc: String, iconUrl: String?, shots: JSONArray? = null): String =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put("slug", slugify(name) + "-" + Random.nextInt(1000, 9999))
                .put("name", name).put("developer", dev).put("category", cat)
                .put("description", desc).put("is_published", true)
            if (iconUrl != null) body.put("icon_url", iconUrl)
            if (pkg.isNotBlank()) body.put("package_name", pkg)
            if (shots != null) body.put("screenshots", shots)
            val arr = JSONArray(call("POST", "/rest/v1/apps", body, token, "return=representation"))
            arr.getJSONObject(0).getString("id")
        }

    suspend fun updateApp(token: String, id: String, fields: JSONObject) = withContext(Dispatchers.IO) {
        fields.put("updated_at", nowIso())
        call("PATCH", "/rest/v1/apps?id=eq.$id", fields, token)
        Unit
    }

    suspend fun addVersion(token: String, appId: String, version: String, apkUrl: String, size: Long?, changelog: String) =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("app_id", appId).put("version_name", version).put("apk_url", apkUrl)
            if (size != null) body.put("size_bytes", size)
            if (changelog.isNotBlank()) body.put("changelog", changelog)
            call("POST", "/rest/v1/app_versions", body, token)
            call("PATCH", "/rest/v1/apps?id=eq.$appId", JSONObject().put("updated_at", nowIso()), token)
            Unit
        }

    suspend fun deleteApp(token: String, id: String) = withContext(Dispatchers.IO) {
        call("DELETE", "/rest/v1/apps?id=eq.$id", null, token)
        Unit
    }
}

class SessionStore(context: Context) {
    private val p = context.getSharedPreferences("arman_session", Context.MODE_PRIVATE)

    fun save(s: UserSession) {
        p.edit().putString("at", s.accessToken).putString("rt", s.refreshToken)
            .putLong("exp", s.expiresAtSec).putString("uid", s.userId).putString("email", s.email).apply()
    }

    fun load(): UserSession? {
        val at = p.getString("at", null) ?: return null
        val rt = p.getString("rt", null) ?: return null
        val uid = p.getString("uid", null) ?: return null
        return UserSession(at, rt, p.getLong("exp", 0), uid, p.getString("email", "") ?: "")
    }

    fun clear() {
        p.edit().remove("at").remove("rt").remove("exp").remove("uid").remove("email").apply()
    }

    fun loadInstalled(): Set<String>? = p.getStringSet("inst", null)
    fun saveInstalled(v: Set<String>) { p.edit().putStringSet("inst", v.toSet()).apply() }

    fun loadBn(): Boolean = p.getBoolean("bn", true)
    fun saveBn(v: Boolean) { p.edit().putBoolean("bn", v).apply() }
}
