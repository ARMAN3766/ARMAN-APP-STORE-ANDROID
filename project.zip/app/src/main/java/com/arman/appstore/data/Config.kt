package com.arman.appstore.data

/** Only PUBLIC values live here. Never put a secret/service_role key in the app. */
object Config {
    const val SUPABASE_URL = "https://sbmnqhpnhxnklnejmiog.supabase.co"
    const val SUPABASE_KEY = "sb_publishable_jBzTEKOPku8SfPhpFv221Q_dBKlj4Oz"

    /** Public Google "Web application" client ID. Leave empty until Google sign-in is set up; the button stays hidden. */
    const val GOOGLE_WEB_CLIENT_ID = ""
}
