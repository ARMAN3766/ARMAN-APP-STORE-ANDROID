package com.arman.appstore.data

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

enum class TaskState { PENDING, DOWNLOADING, READY, INSTALLING, DONE, FAILED, CANCELLED }

fun TaskState.busy(): Boolean =
    this == TaskState.PENDING || this == TaskState.DOWNLOADING || this == TaskState.READY || this == TaskState.INSTALLING

class DlTask(
    val appId: String,
    val appName: String,
    val iconUrl: String?,
    val packageName: String,
    val versionName: String,
    val url: String,
    val fileName: String,
    val isUpdate: Boolean
) {
    var state by mutableStateOf(TaskState.PENDING)
    var bytes by mutableLongStateOf(0L)
    var total by mutableLongStateOf(0L)
    var speed by mutableLongStateOf(0L)
    var error by mutableStateOf<String?>(null)
    var downloadId = -1L
    var sessionId = -1
    var filePath: String? = null
    var verifiedPkg = ""
    var lastBytes = 0L
    var lastTime = 0L

    val fraction: Float get() = if (total > 0) (bytes.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f

    fun reset() {
        state = TaskState.PENDING
        bytes = 0L; total = 0L; speed = 0L
        error = null
        downloadId = -1L; sessionId = -1
        filePath = null; verifiedPkg = ""; lastBytes = 0L; lastTime = 0L
    }
}

/**
 * One place for every download and install. Downloads are done by Android's DownloadManager
 * (so they continue when the app is closed); installs are done by Android's PackageInstaller.
 * All numbers shown in the UI come from those two real sources.
 */
object DownloadCenter {
    val tasks = mutableStateListOf<DlTask>()
    var permissionNeeded by mutableStateOf(false)
    var onChanged: (() -> Unit)? = null

    private const val MAX_PARALLEL = 2
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var poller: Job? = null

    fun init(ctx: Context) { app = ctx.applicationContext }

    fun find(appId: String): DlTask? = tasks.firstOrNull { it.appId == appId }

    fun enqueue(t: DlTask) {
        if (!::app.isInitialized) return
        val existing = find(t.appId)
        if (existing != null && existing.state.busy()) return
        if (existing != null) tasks.remove(existing)
        tasks.add(0, t)
        pump()
    }

    fun retry(t: DlTask) {
        t.reset()
        pump()
    }

    fun clearFinished() {
        tasks.removeAll { !it.state.busy() }
    }

    fun cancel(t: DlTask) {
        if (!::app.isInitialized) return
        when (t.state) {
            TaskState.DOWNLOADING -> {
                try { app.getSystemService(DownloadManager::class.java).remove(t.downloadId) } catch (e: Exception) { /* ignore */ }
                Downloads.forget(app, t.downloadId)
                t.state = TaskState.CANCELLED
            }
            TaskState.PENDING -> t.state = TaskState.CANCELLED
            TaskState.READY -> {
                t.filePath?.let { File(it).delete() }
                t.state = TaskState.CANCELLED
            }
            TaskState.INSTALLING -> {
                try { app.packageManager.packageInstaller.abandonSession(t.sessionId) } catch (e: Exception) { /* ignore */ }
                t.state = TaskState.CANCELLED
            }
            else -> {}
        }
        t.error = null
        pump()
    }

    /** Called by the Install button and when the app returns to the screen. */
    fun resume() {
        if (!::app.isInitialized) return
        installNext()
        pump()
    }

    fun installNow() {
        if (!::app.isInitialized) return
        if (!Updater.canInstall(app)) Updater.openInstallSettings(app) else installNext()
    }

    private fun pump() {
        if (!::app.isInitialized) return
        var slots = MAX_PARALLEL - tasks.count { it.state == TaskState.DOWNLOADING }
        for (t in tasks.reversed()) {
            if (slots <= 0) break
            if (t.state == TaskState.PENDING) {
                startDownload(t)
                slots--
            }
        }
        if (tasks.any { it.state == TaskState.DOWNLOADING }) ensurePoller()
        installNext()
    }

    private fun startDownload(t: DlTask) {
        try {
            t.downloadId = Downloads.enqueue(app, t.url, t.fileName, t.appName + " " + t.versionName)
            t.state = TaskState.DOWNLOADING
            t.lastBytes = 0L
            t.lastTime = 0L
        } catch (e: Exception) {
            t.state = TaskState.FAILED
            t.error = "download"
        }
    }

    private fun ensurePoller() {
        if (poller?.isActive == true) return
        poller = scope.launch {
            while (tasks.any { it.state == TaskState.DOWNLOADING }) {
                poll()
                delay(500)
            }
        }
    }

    private fun poll() {
        val dm = app.getSystemService(DownloadManager::class.java)
        for (t in tasks.toList()) {
            if (t.state != TaskState.DOWNLOADING) continue
            dm.query(DownloadManager.Query().setFilterById(t.downloadId)).use { c ->
                if (c == null || !c.moveToFirst()) {
                    t.state = TaskState.CANCELLED
                    return@use
                }
                val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val now = SystemClock.elapsedRealtime()
                if (t.lastTime > 0 && now > t.lastTime && got >= t.lastBytes) {
                    val inst = (got - t.lastBytes) * 1000 / (now - t.lastTime)
                    t.speed = if (t.speed == 0L) inst else (t.speed * 6 + inst * 4) / 10
                }
                t.lastBytes = got
                t.lastTime = now
                t.bytes = got
                if (total > 0) t.total = total
                when (st) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        val uri = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                        t.filePath = if (uri != null) Uri.parse(uri).path else null
                        t.speed = 0L
                        t.state = TaskState.READY
                    }
                    DownloadManager.STATUS_FAILED -> {
                        t.state = TaskState.FAILED
                        t.error = "download"
                    }
                    else -> {}
                }
            }
        }
        pump()
    }

    /** Called by DownloadReceiver; returns false if this download does not belong to a live task. */
    fun handleComplete(id: Long, path: String): Boolean {
        val t = tasks.firstOrNull { it.downloadId == id } ?: return false
        if (t.state == TaskState.DOWNLOADING) {
            t.filePath = path
            t.speed = 0L
            t.state = TaskState.READY
        }
        pump()
        return true
    }

    private fun installNext() {
        if (!::app.isInitialized) return
        if (tasks.any { it.state == TaskState.INSTALLING }) return
        while (true) {
            val t = tasks.lastOrNull { it.state == TaskState.READY }
            if (t == null) {
                permissionNeeded = false
                return
            }
            if (!Updater.canInstall(app)) {
                permissionNeeded = true
                return
            }
            permissionNeeded = false
            val file = t.filePath?.let { File(it) }
            if (file == null || !file.exists()) {
                t.state = TaskState.FAILED
                t.error = "missing"
                continue
            }
            val v = PackageTools.verifyApk(app, file, t.packageName)
            if (!v.ok) {
                t.state = TaskState.FAILED
                t.error = v.code
                continue
            }
            t.verifiedPkg = v.pkg
            try {
                t.sessionId = Installer.install(app, file, v.pkg)
                t.state = TaskState.INSTALLING
            } catch (e: Exception) {
                t.state = TaskState.FAILED
                t.error = "failed"
                continue
            }
            return
        }
    }

    /** Real result sent by Android's PackageInstaller. */
    fun onInstallResult(pkg: String, ok: Boolean, code: String) {
        val t = tasks.firstOrNull { it.state == TaskState.INSTALLING && it.verifiedPkg == pkg }
            ?: tasks.firstOrNull { it.state == TaskState.INSTALLING }
        if (t != null) {
            if (ok) {
                t.state = TaskState.DONE
                t.error = null
            } else {
                t.state = if (code == "cancelled") TaskState.CANCELLED else TaskState.FAILED
                t.error = code
            }
            t.filePath?.let { File(it).delete() }
        }
        onChanged?.invoke()
        if (::app.isInitialized) installNext()
    }
}
