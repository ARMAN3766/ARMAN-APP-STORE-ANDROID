package com.arman.appstore.data

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import java.io.File

/** True only while the app screen is visible. */
object AppState {
    @Volatile var foreground = false
}

/** Downloads are handed to the Android system, so they continue even if the app is closed. */
object Downloads {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("arman_dl", Context.MODE_PRIVATE)

    fun enqueue(ctx: Context, url: String, fileName: String, title: String): Long {
        val dm = ctx.getSystemService(DownloadManager::class.java)
        File(ctx.getExternalFilesDir(null), "apks").mkdirs()
        File(ctx.getExternalFilesDir(null), "apks/$fileName").delete()
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(title)
            .setDescription("ARMAN APP STORE")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(ctx, null, "apks/$fileName")
        val id = dm.enqueue(req)
        prefs(ctx).edit().putBoolean("d$id", true).apply()
        return id
    }

    fun isOurs(ctx: Context, id: Long): Boolean = prefs(ctx).getBoolean("d$id", false)
    fun forget(ctx: Context, id: Long) { prefs(ctx).edit().remove("d$id").apply() }

    fun cleanup(ctx: Context) {
        val dir = File(ctx.getExternalFilesDir(null), "apks")
        dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 86400000L) it.delete() }
    }
}

/** Finished downloads waiting for the Android install screen, opened one by one. */
object InstallQueue {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("arman_queue", Context.MODE_PRIVATE)

    private fun load(ctx: Context): MutableSet<String> =
        (prefs(ctx).getStringSet("q", emptySet()) ?: emptySet()).toMutableSet()

    private fun save(ctx: Context, s: Set<String>) { prefs(ctx).edit().putStringSet("q", s.toSet()).apply() }

    fun add(ctx: Context, path: String) { val s = load(ctx); s.add(path); save(ctx, s) }

    fun size(ctx: Context): Int = load(ctx).count { File(it).exists() }

    /** Opens the installer for the next file. Returns true if an installer was opened. */
    fun launchNext(ctx: Context): Boolean {
        val s = load(ctx)
        val p = s.firstOrNull { File(it).exists() }
        if (p == null) { save(ctx, emptySet()); return false }
        s.remove(p)
        save(ctx, s)
        val ok = Updater.install(ctx, File(p))
        if (!ok) add(ctx, p)
        return ok
    }
}
