package com.arman.appstore.data

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import com.arman.appstore.InstallStatusReceiver
import java.io.File

/** Installs an APK through Android's own PackageInstaller. Android always asks the user to confirm. */
object Installer {
    const val ACTION = "com.arman.appstore.INSTALL_STATUS"

    fun install(ctx: Context, apk: File, pkg: String): Int {
        val pi = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        if (pkg.isNotBlank()) params.setAppPackageName(pkg)
        val id = pi.createSession(params)
        pi.openSession(id).use { session ->
            apk.inputStream().use { input ->
                session.openWrite("base.apk", 0, apk.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val intent = Intent(ctx, InstallStatusReceiver::class.java).setAction(ACTION).putExtra("pkg", pkg)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            session.commit(PendingIntent.getBroadcast(ctx, id, intent, flags).intentSender)
        }
        return id
    }
}
