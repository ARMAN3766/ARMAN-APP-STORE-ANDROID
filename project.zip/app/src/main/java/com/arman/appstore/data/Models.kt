package com.arman.appstore.data

data class AppVersion(
    val versionName: String,
    val apkUrl: String,
    val sizeBytes: Long?,
    val changelog: String?,
    val createdAt: String
)

data class StoreApp(
    val id: String,
    val name: String,
    val developer: String,
    val category: String,
    val description: String,
    val iconUrl: String?,
    val updatedAt: String,
    val versions: List<AppVersion>
) {
    val latest: AppVersion? get() = versions.maxByOrNull { it.createdAt }
}

data class UserSession(
    val accessToken: String,
    val refreshToken: String,
    val expiresAtSec: Long,
    val userId: String,
    val email: String
)

data class Profile(val email: String, val role: String) {
    val isAdmin: Boolean get() = role == "admin"
}
