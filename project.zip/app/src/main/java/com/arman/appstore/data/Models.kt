package com.arman.appstore.data

data class AppVersion(
    val id: String,
    val versionName: String,
    val apkUrl: String,
    val sizeBytes: Long?,
    val changelog: String?,
    val createdAt: String
)

data class StoreApp(
    val id: String,
    val name: String,
    val developer: String,
    val category: String,
    val description: String,
    val iconUrl: String?,
    val packageName: String,
    val updatedAt: String,
    val published: Boolean,
    val versions: List<AppVersion>
) {
    val latest: AppVersion? get() = versions.maxByOrNull { it.createdAt }
}

data class UserSession(
    val accessToken: String,
    val refreshToken: String,
    val expiresAtSec: Long,
    val userId: String,
    val email: String
)

data class Profile(val email: String, val role: String) {
    val isAdmin: Boolean get() = role == "admin"
}

data class HistoryItem(
    val appId: String,
    val appName: String,
    val iconUrl: String?,
    val packageName: String,
    val action: String,
    val createdAt: String
)

data class Flagged(val label: String, val pkg: String, val reasons: List<String>, val high: Boolean)

data class ScanResult(val timeMillis: Long, val total: Int, val flagged: List<Flagged>)
