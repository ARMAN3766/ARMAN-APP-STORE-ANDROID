package com.arman.appstore.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.io.File

data class DeviceApp(
    val label: String,
    val pkg: String,
    val versionName: String,
    val apkSize: Long,
    val lastUpdate: Long,
    val isGame: Boolean
)

/** code is one of: ok, bad_apk, wrong_package, downgrade, signature */
data class VerifyResult(val ok: Boolean, val code: String, val pkg: String, val versionName: String)

object PackageTools {

    fun loadDeviceApps(ctx: Context): List<DeviceApp> {
        val pm = ctx.packageManager
        val out = mutableListOf<DeviceApp>()
        for (p in pm.getInstalledPackages(0)) {
            val ai = p.applicationInfo ?: continue
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val updatedSystem = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            if (isSystem && !updatedSystem) continue
            val game = Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME
            val size = try { File(ai.sourceDir).length() } catch (e: Exception) { 0L }
            out.add(DeviceApp(pm.getApplicationLabel(ai).toString(), p.packageName, p.versionName ?: "", size, p.lastUpdateTime, game))
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun versionCodeOf(p: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong()

    @Suppress("DEPRECATION")
    private fun sigFlags(): Int =
        if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES

    @Suppress("DEPRECATION")
    private fun signaturesOf(p: PackageInfo): Set<String> {
        if (Build.VERSION.SDK_INT >= 28) {
            val si = p.signingInfo ?: return emptySet()
            val arr = if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
            return arr?.map { it.toCharsString() }?.toSet() ?: emptySet()
        }
        return p.signatures?.map { it.toCharsString() }?.toSet() ?: emptySet()
    }

    /** Checks the downloaded APK before handing it to Android's installer. */
    fun verifyApk(ctx: Context, file: File, expectedPkg: String?): VerifyResult {
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(file.path, sigFlags()) ?: return VerifyResult(false, "bad_apk", "", "")
        val name = info.packageName ?: return VerifyResult(false, "bad_apk", "", "")
        val ver = info.versionName ?: ""
        if (!expectedPkg.isNullOrBlank() && name != expectedPkg) return VerifyResult(false, "wrong_package", name, ver)
        val installed = try { pm.getPackageInfo(name, sigFlags()) } catch (e: PackageManager.NameNotFoundException) { null }
        if (installed != null) {
            if (versionCodeOf(info) < versionCodeOf(installed)) return VerifyResult(false, "downgrade", name, ver)
            val a = signaturesOf(info)
            val b = signaturesOf(installed)
            if (a.isNotEmpty() && b.isNotEmpty() && a.none { it in b }) return VerifyResult(false, "signature", name, ver)
        }
        return VerifyResult(true, "ok", name, ver)
    }
}
