package com.arman.appstore.data

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.arman.appstore.R

/** Basic on-device check based on installed apps' permissions. It is NOT a full antivirus. */
object Scanner {
    private val sms = setOf("android.permission.SEND_SMS", "android.permission.RECEIVE_SMS", "android.permission.READ_SMS")

    fun scan(ctx: Context): ScanResult {
        val pm = ctx.packageManager
        val pkgs = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES)
        var total = 0
        val out = mutableListOf<Flagged>()
        for (p in pkgs) {
            val ai = p.applicationInfo ?: continue
            if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            total++
            val perms = p.requestedPermissions?.toSet() ?: emptySet()
            @Suppress("DEPRECATION")
            val installer = try { pm.getInstallerPackageName(p.packageName) } catch (e: Exception) { null }
            val fromPlay = installer == "com.android.vending"
            val a11y = p.services?.any { it.permission == "android.permission.BIND_ACCESSIBILITY_SERVICE" } == true
            val overlay = "android.permission.SYSTEM_ALERT_WINDOW" in perms
            val hasSms = perms.any { it in sms }
            val installs = "android.permission.REQUEST_INSTALL_PACKAGES" in perms
            val reasons = mutableListOf<String>()
            if (a11y) reasons.add("a11y")
            if (overlay) reasons.add("overlay")
            if (hasSms) reasons.add("sms")
            if (installs) reasons.add("installs")
            val high = a11y && (overlay || hasSms)
            val medium = !fromPlay && (a11y || hasSms || (overlay && installs))
            if (high || medium) {
                out.add(Flagged(pm.getApplicationLabel(ai).toString(), p.packageName, reasons, high))
            }
        }
        out.sortByDescending { it.high }
        return ScanResult(System.currentTimeMillis(), total, out)
    }
}

object Notifier {
    fun installReady(ctx: Context, count: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("downloads", "Downloads", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val pi = android.app.PendingIntent.getActivity(
            ctx, 0,
            android.content.Intent(ctx, com.arman.appstore.MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, "downloads")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("ARMAN APP STORE")
            .setContentText("$count app(s) ready to install - tap to continue")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(2, n)
    }

    fun threats(ctx: Context, count: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("protect", "App Protect", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val n = NotificationCompat.Builder(ctx, "protect")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("ARMAN APP STORE - App Protect")
            .setContentText("$count app(s) need your attention")
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }
}
