package com.arman.appstore.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class UpdateInfo(val versionName: String, val apkUrl: String, val notes: String)

/** Self-update: reads the newest GitHub Release of this app, downloads the APK, opens the Android installer. */
object Updater {
    private const val LATEST_API = "https://api.github.com/repos/ARMAN3766/ARMAN-APP-STORE-ANDROID/releases/latest"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun currentVersion(ctx: Context): String =
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "0"

    private fun parts(v: String): List<Int> =
        v.trim().trimStart('v', 'V').split(".").map { it.takeWhile { c -> c.isDigit() }.toIntOrNull() ?: 0 }

    fun isNewer(remote: String, local: String): Boolean {
        val a = parts(remote)
        val b = parts(local)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    suspend fun check(ctx: Context): UpdateInfo? = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(LATEST_API).header("Accept", "application/vnd.github+json").build()
        val (code, text) = client.newCall(req).execute().use { it.code to it.body?.string().orEmpty() }
        if (code == 404) return@withContext null
        if (code !in 200..299) throw ApiException("HTTP $code", code)
        val j = JSONObject(text)
        val tag = j.optString("tag_name")
        val assets = j.optJSONArray("assets") ?: JSONArray()
        var url: String? = null
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name").endsWith(".apk")) {
                url = a.optString("browser_download_url")
                break
            }
        }
        if (url == null || !isNewer(tag, currentVersion(ctx))) null
        else UpdateInfo(tag.trimStart('v', 'V'), url, j.optString("body", ""))
    }

    suspend fun download(ctx: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "updates")
        dir.mkdirs()
        val file = File(dir, "update.apk")
        if (file.exists()) file.delete()
        val req = Request.Builder().url(info.apkUrl).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiException("HTTP ${r.code}", r.code)
            val body = r.body ?: throw ApiException("empty", 0)
            val total = body.contentLength()
            body.byteStream().use { input ->
                file.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n == -1) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last) { last = p; onProgress(p) }
                        }
                    }
                }
            }
        }
        file
    }

    /** Returns false when the user must first allow "install unknown apps" for this app. */
    fun install(ctx: Context, apk: File): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }
}
