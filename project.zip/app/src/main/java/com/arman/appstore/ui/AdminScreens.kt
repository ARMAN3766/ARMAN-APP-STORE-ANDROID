@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.arman.appstore.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arman.appstore.data.Api
import com.arman.appstore.data.StoreApp

private fun adminErr(code: String): String = when (code) {
    "need_name" -> tr("অ্যাপের নাম লিখুন।", "Enter the app name.")
    "need_version" -> tr("ভার্সন লিখুন (যেমন 1.0.0)।", "Enter a version (e.g. 1.0.0).")
    "need_apk" -> tr("APK ফাইল বাছুন অথবা https:// দিয়ে শুরু হওয়া লিংক দিন।", "Pick an APK file or enter an https:// link.")
    "bad_apk" -> tr("বাছাই করা ফাইলটি .apk নয়।", "The chosen file is not an .apk.")
    else -> friendly(code)
}

private fun statusText(code: String?, p: Int?): String = when (code) {
    "upload_apk" -> tr("APK আপলোড হচ্ছে… ", "Uploading APK… ") + (if (p != null) "$p%" else "")
    "upload_icon" -> tr("আইকন আপলোড হচ্ছে…", "Uploading icon…")
    "saving" -> tr("সংরক্ষণ হচ্ছে…", "Saving…")
    else -> tr("অপেক্ষা করুন…", "Please wait…")
}

@Composable
fun AdminHost(vm: StoreViewModel) {
    var mode by rememberSaveable { mutableStateOf("list") }
    var targetId by rememberSaveable { mutableStateOf<String?>(null) }
    val target = vm.apps.firstOrNull { it.id == targetId }

    BackHandler(enabled = mode != "list") { mode = "list"; vm.clearAdminError() }
    LaunchedEffect(vm.adminDone) {
        if (vm.adminDone) { vm.clearAdminDone(); mode = "list" }
    }

    when (mode) {
        "new" -> AppEditor(vm, null, true, true) { mode = "list"; vm.clearAdminError() }
        "edit" -> if (target != null) AppEditor(vm, target, true, false) { mode = "list"; vm.clearAdminError() } else mode = "list"
        "version" -> if (target != null) AppEditor(vm, target, false, true) { mode = "list"; vm.clearAdminError() } else mode = "list"
        else -> AdminList(
            vm,
            onNew = { mode = "new" },
            onEdit = { targetId = it.id; mode = "edit" },
            onVersion = { targetId = it.id; mode = "version" }
        )
    }
}

@Composable
private fun AdminList(vm: StoreViewModel, onNew: () -> Unit, onEdit: (StoreApp) -> Unit, onVersion: (StoreApp) -> Unit) {
    var confirm by remember { mutableStateOf<StoreApp?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(tr("অ্যাডমিন প্যানেল", "Admin panel"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onNew, enabled = !vm.adminBusy, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Icon(Icons.Filled.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text(tr("নতুন অ্যাপ যোগ করুন", "Add new app"))
                }
            }
        }
        vm.adminError?.let { item { Text(adminErr(it), color = MaterialTheme.colorScheme.error) } }
        if (vm.adminBusy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (vm.apps.isEmpty()) {
            item { Text(tr("এখনও কোনো অ্যাপ নেই।", "No apps yet."), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(vm.apps, key = { it.id }) { a ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface).padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(a, 48.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            (a.latest?.let { "v" + it.versionName } ?: tr("ভার্সন নেই", "No version")) + "  •  " +
                                if (a.published) tr("প্রকাশিত", "Published") else tr("লুকানো", "Hidden"),
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = a.published, onCheckedChange = { vm.setPublished(a.id, it) }, enabled = !vm.adminBusy)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { onVersion(a) }, enabled = !vm.adminBusy) { Text(tr("নতুন ভার্সন", "New version")) }
                    TextButton(onClick = { onEdit(a) }, enabled = !vm.adminBusy) { Text(tr("সম্পাদনা", "Edit")) }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { confirm = a }, enabled = !vm.adminBusy) {
                        Icon(Icons.Filled.Delete, tr("মুছুন", "Delete"), tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    confirm?.let { a ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(tr("অ্যাপ মুছবেন?", "Delete app?")) },
            text = { Text(a.name + tr(" এবং এর সব ভার্সন মুছে যাবে।", " and all its versions will be removed.")) },
            confirmButton = { TextButton(onClick = { vm.deleteApp(a.id); confirm = null }) { Text(tr("মুছুন", "Delete")) } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text(tr("বাতিল", "Cancel")) } }
        )
    }
}

@Composable
private fun AppEditor(vm: StoreViewModel, app: StoreApp?, showInfo: Boolean, showVersion: Boolean, onBack: () -> Unit) {
    val key = app?.id ?: "new"
    var name by rememberSaveable(key) { mutableStateOf(app?.name ?: "") }
    var dev by rememberSaveable(key) { mutableStateOf(app?.developer ?: "") }
    var cat by rememberSaveable(key) { mutableStateOf(app?.category ?: "Tools") }
    var desc by rememberSaveable(key) { mutableStateOf(app?.description ?: "") }
    var icon by rememberSaveable(key) { mutableStateOf<Uri?>(null) }
    var version by rememberSaveable(key) { mutableStateOf("") }
    var log by rememberSaveable(key) { mutableStateOf("") }
    var useUrl by rememberSaveable(key) { mutableStateOf(false) }
    var apkUrl by rememberSaveable(key) { mutableStateOf("") }
    var apk by rememberSaveable(key) { mutableStateOf<Uri?>(null) }

    val ctx = LocalContext.current
    val pickIcon = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) icon = it }
    val pickApk = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) apk = it }
    val iconName = remember(icon) { icon?.let { Api.fileInfo(ctx, it).first } }
    val apkName = remember(apk) { apk?.let { Api.fileInfo(ctx, it).first } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, enabled = !vm.adminBusy) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("পেছনে", "Back")) }
            Text(
                when {
                    app == null -> tr("নতুন অ্যাপ", "New app")
                    showInfo -> tr("অ্যাপ সম্পাদনা", "Edit app")
                    else -> tr("নতুন ভার্সন: ", "New version: ") + app.name
                },
                fontSize = 20.sp, fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(12.dp))

        if (showInfo) {
            OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text(tr("অ্যাপের নাম", "App name")) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = dev, onValueChange = { dev = it }, singleLine = true, label = { Text(tr("ডেভেলপার", "Developer")) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = cat, onValueChange = { cat = it }, singleLine = true, label = { Text(tr("ক্যাটাগরি (যেমন Tools, Games)", "Category (e.g. Tools, Games)")) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = desc, onValueChange = { desc = it }, minLines = 3, label = { Text(tr("বিবরণ", "Description")) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { pickIcon.launch("image/*") }, enabled = !vm.adminBusy, modifier = Modifier.fillMaxWidth()) {
                Text(iconName ?: tr("আইকন বাছুন (PNG/JPG)", "Choose icon (PNG/JPG)"))
            }
        }

        if (showVersion) {
            Spacer(Modifier.height(16.dp))
            Text(tr("ভার্সন ও APK", "Version & APK"), fontWeight = FontWeight.SemiBold)
            app?.latest?.let { Text(tr("বর্তমান ভার্সন: ", "Current version: ") + it.versionName, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = version, onValueChange = { version = it }, singleLine = true, label = { Text(tr("ভার্সন (যেমন 1.0.1)", "Version (e.g. 1.0.1)")) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = log, onValueChange = { log = it }, minLines = 2, label = { Text(tr("নতুন কী আছে", "What's new")) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !useUrl, onClick = { useUrl = false }, label = { Text(tr("ফাইল থেকে (≤৫০MB)", "From file (≤50MB)")) })
                FilterChip(selected = useUrl, onClick = { useUrl = true }, label = { Text(tr("লিংক দিয়ে", "From link")) })
            }
            Spacer(Modifier.height(8.dp))
            if (useUrl) {
                OutlinedTextField(value = apkUrl, onValueChange = { apkUrl = it }, singleLine = true, label = { Text(tr("APK লিংক (https://…)", "APK link (https://…)")) }, modifier = Modifier.fillMaxWidth())
            } else {
                OutlinedButton(onClick = { pickApk.launch("*/*") }, enabled = !vm.adminBusy, modifier = Modifier.fillMaxWidth()) {
                    Text(apkName ?: tr("APK ফাইল বাছুন", "Choose APK file"))
                }
            }
        }

        vm.adminError?.let { Text(adminErr(it), color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp)) }
        if (vm.adminBusy) {
            Spacer(Modifier.height(12.dp))
            Text(statusText(vm.adminStatus, vm.adminProgress), fontSize = 13.sp)
            val p = vm.adminProgress
            if (p != null) LinearProgressIndicator(progress = p / 100f, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            else LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp))
        }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                when {
                    app == null -> vm.createApp(name, dev, cat, desc, icon, version, log, if (useUrl) null else apk, if (useUrl) apkUrl else "")
                    showInfo -> vm.saveInfo(app, name, dev, cat, desc, icon)
                    else -> vm.addVersion(app, version, log, if (useUrl) null else apk, if (useUrl) apkUrl else "")
                }
            },
            enabled = !vm.adminBusy,
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text(
                when {
                    app == null -> tr("অ্যাপ প্রকাশ করুন", "Publish app")
                    showInfo -> tr("সংরক্ষণ করুন", "Save")
                    else -> tr("ভার্সন প্রকাশ করুন", "Publish version")
                }
            )
        }
        Spacer(Modifier.height(32.dp))
    }
}
