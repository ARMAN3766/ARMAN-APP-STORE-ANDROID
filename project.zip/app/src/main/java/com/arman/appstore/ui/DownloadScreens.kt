@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.arman.appstore.ui

import android.os.Environment
import android.os.StatFs
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import com.arman.appstore.R
import com.arman.appstore.data.DeviceApp
import com.arman.appstore.data.DlTask
import com.arman.appstore.data.DownloadCenter
import com.arman.appstore.data.HistoryItem
import com.arman.appstore.data.StoreApp
import com.arman.appstore.data.TaskState
import com.arman.appstore.data.busy

// ---------- helpers ----------

internal fun mb(bytes: Long): String = String.format("%.1f MB", bytes / 1048576.0)

private fun gbText(bytes: Long): String = String.format("%.1f GB", bytes / 1073741824.0)

internal fun taskErr(code: String?): String = when (code) {
    null -> ""
    "signature" -> tr(
        "আগে ইনস্টল করা অ্যাপের সাইন-কী আলাদা, তাই আপডেট বসছে না। আগের অ্যাপ আনইনস্টল করে আবার ইনস্টল করুন।",
        "The installed app was signed with a different key, so it cannot be updated. Uninstall it and install again."
    )
    "downgrade" -> tr("ফোনে এর চেয়ে নতুন বা সমান ভার্সন আছে। পুরোনো ভার্সনে নামানো যায় না।", "A newer or equal version is already installed. Downgrading is not allowed.")
    "wrong_package" -> tr("ফাইলটি অন্য অ্যাপের। প্যাকেজ নাম মেলেনি।", "This file belongs to a different app (package name mismatch).")
    "bad_apk" -> tr("APK ফাইলটি ঠিক নেই বা নষ্ট।", "The APK file is invalid or damaged.")
    "storage" -> tr("ফোনে জায়গা কম।", "Not enough storage on the phone.")
    "blocked" -> tr("Android ইনস্টল আটকে দিয়েছে। Play Protect বা অনুমতি দেখুন।", "Android blocked the installation. Check Play Protect and permissions.")
    "incompatible" -> tr("এই ফোনের সঙ্গে অ্যাপটি মেলে না।", "This app is not compatible with this phone.")
    "cancelled" -> tr("আপনি ইনস্টল বাতিল করেছেন।", "You cancelled the installation.")
    "download" -> tr("ডাউনলোড ব্যর্থ হয়েছে। ইন্টারনেট দেখে আবার চেষ্টা করুন।", "Download failed. Check your connection and try again.")
    "missing" -> tr("ডাউনলোড করা ফাইল পাওয়া যায়নি।", "The downloaded file was not found.")
    else -> tr("ইনস্টল ব্যর্থ হয়েছে।", "Installation failed.")
}

private fun stateText(s: TaskState): String = when (s) {
    TaskState.PENDING -> tr("অপেক্ষায়", "Waiting")
    TaskState.DOWNLOADING -> tr("ডাউনলোড হচ্ছে", "Downloading")
    TaskState.READY -> tr("ডাউনলোড শেষ, ইনস্টলের অপেক্ষায়", "Downloaded, waiting to install")
    TaskState.INSTALLING -> tr("ইনস্টল হচ্ছে, Android-এর স্ক্রিনে নিশ্চিত করুন", "Installing, confirm on the Android screen")
    TaskState.DONE -> tr("ইনস্টল হয়েছে", "Installed")
    TaskState.FAILED -> tr("ব্যর্থ", "Failed")
    TaskState.CANCELLED -> tr("বাতিল", "Cancelled")
}

@Composable
private fun TaskIcon(t: DlTask, size: Dp) {
    val shape = RoundedCornerShape(size / 4)
    if (t.appId == "self") {
        Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(size).clip(shape))
    } else if (!t.iconUrl.isNullOrBlank()) {
        AsyncImage(
            model = t.iconUrl, contentDescription = t.appName, contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)
        )
    } else {
        Box(Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Text(t.appName.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
private fun DeviceAppIcon(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (e: Exception) { null }
    }
    val shape = RoundedCornerShape(size / 4)
    if (bmp != null) Image(bmp, null, Modifier.size(size).clip(shape))
    else Box(Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant))
}

// ---------- download card: icon, animated circle, bar, MB, speed, cancel / install ----------

@Composable
internal fun TaskCard(vm: StoreViewModel, t: DlTask) {
    val pct = (t.fraction * 100).toInt()
    val anim by animateFloatAsState(targetValue = t.fraction, animationSpec = tween(400), label = "progress")
    val downloading = t.state == TaskState.PENDING || t.state == TaskState.DOWNLOADING || t.state == TaskState.READY

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TaskIcon(t, 52.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(t.appName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("v" + t.versionName + "  •  " + stateText(t.state), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                when (t.state) {
                    TaskState.INSTALLING -> CircularProgressIndicator(Modifier.size(56.dp), strokeWidth = 5.dp)
                    TaskState.DONE -> Text("✓", fontSize = 26.sp, color = MaterialTheme.colorScheme.primary)
                    TaskState.FAILED, TaskState.CANCELLED -> Text("!", fontSize = 26.sp, color = MaterialTheme.colorScheme.error)
                    else -> {
                        CircularProgressIndicator(
                            progress = anim, modifier = Modifier.size(56.dp), strokeWidth = 5.dp,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Text("$pct%", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        if (downloading) {
            LinearProgressIndicator(progress = anim, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
            Text(
                mb(t.bytes) + " / " + (if (t.total > 0) mb(t.total) else "—") +
                    (if (t.state == TaskState.DOWNLOADING && t.speed > 0) "  •  " + mb(t.speed) + "/s" else ""),
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
            )
        }
        if (t.error != null) {
            Text(taskErr(t.error), color = MaterialTheme.colorScheme.error, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (downloading || t.state == TaskState.INSTALLING) {
                OutlinedButton(onClick = { DownloadCenter.cancel(t) }) { Text(tr("বাতিল", "Cancel")) }
            }
            if (t.state == TaskState.READY) {
                Button(onClick = { DownloadCenter.installNow() }) { Text(tr("ইনস্টল", "Install")) }
            }
            if (t.state == TaskState.FAILED || t.state == TaskState.CANCELLED) {
                Button(onClick = { DownloadCenter.retry(t) }) { Text(tr("আবার চেষ্টা", "Retry")) }
            }
        }
    }
}

private fun LazyListScope.taskSection(title: String, list: List<DlTask>, vm: StoreViewModel) {
    if (list.isEmpty()) return
    item(key = "title-$title") { SectionTitle(title) }
    items(list, key = { "t-" + it.appId }) { t -> TaskCard(vm, t) }
}

@Composable
private fun PermissionBanner() {
    if (!DownloadCenter.permissionNeeded) return
    Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(14.dp)) {
        Text(updateText("permission"), fontSize = 13.sp)
        Button(onClick = { DownloadCenter.installNow() }, modifier = Modifier.padding(top = 8.dp)) { Text(tr("অনুমতি দিন", "Allow")) }
    }
}

// ---------- Update Manager ----------

@Composable
internal fun UpdateManagerPage(vm: StoreViewModel, onBack: () -> Unit, onOpen: (StoreApp) -> Unit) {
    val tasks = DownloadCenter.tasks.filter { it.isUpdate }
    val pending = vm.updatable.filter { a -> tasks.none { it.appId == a.id && it.state.busy() } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { PageHeader(tr("অ্যাপ আপডেট", "App updates"), onBack) }
        if (vm.update != null) item { UpdateCard(vm) }
        item { PermissionBanner() }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.loadAll(); vm.checkUpdate(true) }, enabled = !vm.loading && !vm.checking) {
                    Text(if (vm.loading || vm.checking) tr("খোঁজা হচ্ছে…", "Checking…") else tr("আপডেট খুঁজুন", "Check for updates"))
                }
                Button(onClick = { vm.updateAll() }, enabled = pending.isNotEmpty()) { Text(tr("সব আপডেট", "Update all")) }
            }
        }
        vm.updateMsg?.let { m -> item { Text(updateText(m), fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(16.dp)) } }
        vm.installMsg?.let { m -> item { Text(updateText(m), fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(16.dp)) } }
        if (pending.isEmpty() && tasks.isEmpty()) {
            item { Text(tr("এখন কোনো আপডেট বাকি নেই।", "No updates pending."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp)) }
        }
        if (pending.isNotEmpty()) {
            item(key = "title-pending") { SectionTitle(tr("পেন্ডিং আপডেট", "Pending updates")) }
            items(pending, key = { "u-" + it.id }) { a ->
                AppRow(a, trailing = {
                    Button(onClick = { vm.installApp(a) }, contentPadding = PaddingValues(horizontal = 16.dp), modifier = Modifier.height(36.dp)) {
                        Text(tr("আপডেট", "Update"), fontSize = 14.sp)
                    }
                }) { onOpen(a) }
            }
        }
        taskSection(tr("ডাউনলোড হচ্ছে", "Downloading"), tasks.filter { it.state == TaskState.PENDING || it.state == TaskState.DOWNLOADING || it.state == TaskState.READY }, vm)
        taskSection(tr("ইনস্টল হচ্ছে", "Installing"), tasks.filter { it.state == TaskState.INSTALLING }, vm)
        taskSection(tr("সফলভাবে আপডেট হয়েছে", "Successfully updated"), tasks.filter { it.state == TaskState.DONE }, vm)
        taskSection(tr("ব্যর্থ আপডেট", "Failed updates"), tasks.filter { it.state == TaskState.FAILED || it.state == TaskState.CANCELLED }, vm)
    }
}

// ---------- Download Manager (every download) ----------

@Composable
internal fun DownloadManagerPage(vm: StoreViewModel, onBack: () -> Unit) {
    val tasks = DownloadCenter.tasks.toList()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { PageHeader(tr("ডাউনলোড ম্যানেজার", "Download manager"), onBack) }
        item { PermissionBanner() }
        if (tasks.isEmpty()) {
            item { Text(tr("এখনও কোনো ডাউনলোড নেই।", "No downloads yet."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp)) }
        }
        taskSection(tr("চলছে", "In progress"), tasks.filter { it.state.busy() }, vm)
        taskSection(tr("শেষ হয়েছে", "Finished"), tasks.filter { !it.state.busy() }, vm)
        if (tasks.any { !it.state.busy() }) {
            item {
                TextButton(onClick = { DownloadCenter.clearFinished() }, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Text(tr("শেষ হওয়াগুলো মুছুন", "Clear finished"))
                }
            }
        }
    }
}

// ---------- Manage apps & device ----------

@Composable
private fun DeviceRow(d: DeviceApp, store: StoreApp?, needsUpdate: Boolean, onOpen: (StoreApp) -> Unit, onUpdate: (StoreApp) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = store != null) { if (store != null) onOpen(store) }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DeviceAppIcon(d.pkg, 48.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(d.label, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(d.pkg, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("v" + d.versionName + "  •  " + mb(d.apkSize) + " APK", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
            if (needsUpdate) Text(tr("আপডেট আছে", "Update available"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
        }
        if (needsUpdate && store != null) {
            Button(onClick = { onUpdate(store) }, contentPadding = PaddingValues(horizontal = 16.dp), modifier = Modifier.height(36.dp)) {
                Text(tr("আপডেট", "Update"), fontSize = 14.sp)
            }
        }
    }
}

@Composable
internal fun ManageAppsPage(vm: StoreViewModel, go: (String) -> Unit, onBack: () -> Unit, onOpen: (StoreApp) -> Unit) {
    var sub by rememberSaveable { mutableStateOf("overview") }
    var filter by rememberSaveable { mutableStateOf("installed") }
    var sort by rememberSaveable { mutableStateOf("alpha") }
    LaunchedEffect(Unit) {
        vm.refreshInstalled()
        vm.loadDeviceApps()
        if (vm.scan == null) vm.runScan(false)
    }
    val st = StatFs(Environment.getDataDirectory().path)
    val total = st.blockCountLong * st.blockSizeLong
    val free = st.availableBlocksLong * st.blockSizeLong
    val used = total - free
    val storeByPkg = vm.apps.filter { it.packageName.isNotBlank() }.associateBy { it.packageName }
    fun isGame(d: DeviceApp) = d.isGame || storeByPkg[d.pkg]?.category.equals("games", true)
    val base = when (filter) {
        "games" -> vm.deviceApps.filter { isGame(it) }
        "apps" -> vm.deviceApps.filter { !isGame(it) }
        else -> vm.deviceApps
    }
    val list = if (sort == "recent") base.sortedByDescending { it.lastUpdate } else base.sortedBy { it.label.lowercase() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { PageHeader(tr("অ্যাপ ও ডিভাইস ম্যানেজ", "Manage apps & device"), onBack) }
        item {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = sub == "overview", onClick = { sub = "overview" }, label = { Text(tr("ওভারভিউ", "Overview")) })
                FilterChip(selected = sub == "manage", onClick = { sub = "manage" }, label = { Text(tr("ম্যানেজ", "Manage")) })
            }
        }
        if (sub == "overview") {
            item {
                val sc = vm.scan
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface).clickable { go("protect") }.padding(16.dp)
                ) {
                    Text(
                        when {
                            vm.scanning || sc == null -> tr("স্ক্যান হচ্ছে…", "Scanning…")
                            sc.flagged.isEmpty() -> tr("কোনো ক্ষতিকর অ্যাপ পাওয়া যায়নি", "No harmful apps found")
                            else -> sc.flagged.size.toString() + tr(" টি অ্যাপে নজর দেওয়া দরকার", " app(s) need attention")
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
                    Text(tr("আপডেট পাওয়া যাচ্ছে", "Available updates"), fontWeight = FontWeight.SemiBold)
                    Text(vm.updatable.size.toString() + tr(" টি আপডেট বাকি", " update(s) pending"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (vm.updatable.isNotEmpty()) {
                        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { vm.updateAll(); go("updates") }) { Text(tr("সব আপডেট", "Update all")) }
                            TextButton(onClick = { go("updates") }) { Text(tr("বিস্তারিত", "Details")) }
                        }
                    }
                    vm.installMsg?.let { Text(updateText(it), fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
                    Text(tr("মোট ইনস্টল করা অ্যাপ", "Total installed apps"), fontWeight = FontWeight.SemiBold)
                    Text(vm.deviceApps.size.toString() + tr(" টি (সিস্টেম অ্যাপ বাদে)", " (excluding system apps)"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(vm.installed.size.toString() + tr(" টি এই স্টোরের তালিকার", " from this store's catalogue"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
                    Text(gbText(used) + tr(" ব্যবহৃত, মোট ", " used of ") + gbText(total), fontWeight = FontWeight.SemiBold)
                    LinearProgressIndicator(progress = if (total > 0) used.toFloat() / total.toFloat() else 0f, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                    Text(tr("খালি: ", "Free: ") + gbText(free), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                }
            }
            item(key = "title-recent") { SectionTitle(tr("সম্প্রতি আপডেট হয়েছে", "Recently updated")) }
            items(vm.storeApps.sortedByDescending { it.updatedAt }.take(5), key = { "r-" + it.id }) { a ->
                AppRow(a, trailing = { InstallPill(vm, a) }) { onOpen(a) }
            }
            item {
                Button(onClick = { go("protect") }, modifier = Modifier.fillMaxWidth().padding(16.dp).height(50.dp)) {
                    Text(tr("ফোনে সমস্যা বা ম্যালওয়্যার স্ক্যান", "Scan phone for problems"))
                }
            }
        } else {
            item {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = filter == "installed", onClick = { filter = "installed" }, label = { Text(tr("ইনস্টল করা", "Installed")) })
                    FilterChip(selected = filter == "updates", onClick = { filter = "updates" }, label = { Text(tr("আপডেট আছে", "Updates available")) })
                    FilterChip(selected = filter == "games", onClick = { filter = "games" }, label = { Text(tr("গেমস", "Games")) })
                    FilterChip(selected = filter == "apps", onClick = { filter = "apps" }, label = { Text(tr("অ্যাপস", "Apps")) })
                }
            }
            if (filter == "updates") {
                if (vm.updatable.isEmpty()) {
                    item { Text(tr("কোনো আপডেট বাকি নেই।", "No updates available."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp)) }
                } else {
                    item { Button(onClick = { vm.updateAll(); go("updates") }, modifier = Modifier.padding(horizontal = 16.dp)) { Text(tr("সব আপডেট", "Update all")) } }
                    items(vm.updatable, key = { "u-" + it.id }) { a ->
                        AppRow(a, trailing = { InstallPill(vm, a) }) { onOpen(a) }
                    }
                }
            } else {
                item {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("সাজান:", "Sort:"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        FilterChip(selected = sort == "alpha", onClick = { sort = "alpha" }, label = { Text(tr("বর্ণানুক্রমে", "A–Z")) })
                        FilterChip(selected = sort == "recent", onClick = { sort = "recent" }, label = { Text(tr("সম্প্রতি আপডেট", "Recently updated")) })
                    }
                }
                if (list.isEmpty()) {
                    item { Text(tr("কোনো অ্যাপ পাওয়া যায়নি।", "No apps found."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp)) }
                }
                items(list, key = { "d-" + it.pkg }) { d ->
                    val s = storeByPkg[d.pkg]
                    val lv = s?.latest?.versionName
                    val needs = s != null && lv != null && com.arman.appstore.data.Updater.isNewer(lv, d.versionName)
                    DeviceRow(d, s, needs, onOpen) { vm.installApp(it) }
                }
            }
        }
    }
}

// ---------- Installation history (this store only) ----------

@Composable
internal fun HistoryPage(vm: StoreViewModel, onBack: () -> Unit, onOpen: (StoreApp) -> Unit) {
    val latest = vm.history.distinctBy { it.appId }
    val uninstalled = latest.filter { it.action == "uninstall" }
    val previously = latest.filter { it.action != "uninstall" && !vm.installed.containsKey(it.packageName) }

    @Composable
    fun row(h: HistoryItem) {
        val app = vm.apps.firstOrNull { it.id == h.appId }
        Row(
            Modifier.fillMaxWidth().clickable(enabled = app != null) { if (app != null) onOpen(app) }.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (app != null) AppIcon(app, 48.dp)
            else Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(h.appName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    when (h.action) {
                        "uninstall" -> tr("আনইনস্টল", "Uninstalled")
                        "install" -> tr("ইনস্টল", "Installed")
                        else -> tr("ডাউনলোড", "Downloaded")
                    } + "  •  " + h.createdAt.take(10) + (if (h.versionName.isNotBlank()) "  •  v" + h.versionName else ""),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (app != null && !vm.installed.containsKey(app.packageName)) {
                Button(onClick = { vm.installApp(app) }, contentPadding = PaddingValues(horizontal = 16.dp), modifier = Modifier.height(36.dp)) {
                    Text(tr("ইনস্টল", "Install"), fontSize = 14.sp)
                }
            }
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { PageHeader(tr("ইনস্টলের ইতিহাস", "Installation history"), onBack) }
        item {
            Text(
                tr(
                    "এখানে শুধু এই স্টোর থেকে ডাউনলোড, ইনস্টল ও আনইনস্টল করা অ্যাপের ইতিহাস থাকে। Android অন্য স্টোর বা Google Play-র ইতিহাস অ্যাপকে দেয় না, তাই তা দেখানো হয় না।",
                    "Only apps downloaded, installed or uninstalled through this store are listed. Android does not share other stores' or Google Play history with apps."
                ),
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
        if (vm.session == null) {
            item { Text(tr("লগইন করলে ইতিহাস ক্লাউডে জমা থাকবে ও সব ডিভাইসে দেখা যাবে।", "Log in to keep your history in the cloud on every device."), modifier = Modifier.padding(16.dp)) }
        } else {
            if (latest.isEmpty()) item { Text(tr("এখনও কোনো ইতিহাস নেই।", "No history yet."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp)) }
            if (previously.isNotEmpty()) {
                item(key = "title-prev") { SectionTitle(tr("আগে ইনস্টল করা", "Previously installed")) }
                items(previously, key = { "p-" + it.appId }) { h -> row(h) }
            }
            if (uninstalled.isNotEmpty()) {
                item(key = "title-unin") { SectionTitle(tr("আনইনস্টল করা অ্যাপ", "Uninstalled apps")) }
                items(uninstalled, key = { "x-" + it.appId }) { h -> row(h) }
            }
        }
    }
}
