@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.arman.appstore.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.arman.appstore.R
import com.arman.appstore.data.Config
import com.arman.appstore.data.StoreApp

// ---------- helpers ----------

internal fun friendly(raw: String?): String {
    val m = raw ?: return ""
    return when {
        m == "network" -> tr("ইন্টারনেট সংযোগ পাওয়া যায়নি। আবার চেষ্টা করুন।", "No internet connection. Try again.")
        m == "google_fail" -> tr("Google দিয়ে লগইন হয়নি। আবার চেষ্টা করুন।", "Google sign-in failed. Please try again.")
        m.contains("expired or is invalid", true) -> tr("কোডটি ভুল অথবা মেয়াদ শেষ। নতুন কোড নিন।", "The code is wrong or expired. Request a new one.")
        m.contains("different from the old", true) -> tr("নতুন পাসওয়ার্ড আগেরটার থেকে আলাদা হতে হবে।", "The new password must differ from the old one.")
        m.contains("Invalid login", true) -> tr("ইমেইল বা পাসওয়ার্ড ভুল।", "Wrong email or password.")
        m.contains("already registered", true) -> tr("এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট আছে। লগইন করুন।", "This email is already registered. Please log in.")
        m.contains("Password should", true) -> tr("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।", "Password must be at least 6 characters.")
        m.contains("Email not confirmed", true) -> tr("ইমেইল এখনও যাচাই হয়নি।", "Email is not confirmed yet.")
        m.contains("exceeded", true) || m.contains("too large", true) -> tr("ফাইল খুব বড় (সর্বোচ্চ ৫০MB)। বদলে APK-র লিংক দিন।", "File too large (50MB max). Use an APK link instead.")
        m.contains("row-level security", true) || m.contains("Unauthorized", true) -> tr("এই কাজের অনুমতি নেই। অ্যাডমিন অ্যাকাউন্টে লগইন করুন।", "Not allowed. Log in with the admin account.")
        m.contains("rate limit", true) -> tr("অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।", "Too many tries. Please wait and try again.")
        else -> m
    }
}

private fun fmtSize(b: Long?): String {
    if (b == null || b <= 0) return "—"
    val mb = b / 1048576.0
    return if (mb >= 1) String.format("%.1f MB", mb) else String.format("%.0f KB", b / 1024.0)
}

@Composable
internal fun AppIcon(app: StoreApp, size: Dp) {
    val shape = RoundedCornerShape(size / 4)
    if (app.iconUrl.isNullOrBlank()) {
        Box(
            Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text(app.name.take(1).uppercase(), fontSize = (size.value / 2.2).sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        }
    } else {
        AsyncImage(
            model = app.iconUrl, contentDescription = app.name, contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)
        )
    }
}

// ---------- root ----------

@Composable
fun AppRoot(vm: StoreViewModel) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        when {
            vm.booting -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(96.dp))
            }
            else -> MainScreen(vm)
        }
    }
}

// ---------- auth (inside the Account tab; browsing never needs login) ----------

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun AuthForm(vm: StoreViewModel) {
    var email by rememberSaveable { mutableStateOf("") }
    var pw by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var showPw by rememberSaveable { mutableStateOf(false) }
    var mode by rememberSaveable { mutableStateOf("login") }
    val ctx = LocalContext.current

    LaunchedEffect(vm.authInfo) { if (vm.authInfo == "reset_sent") mode = "reset" }
    fun go(m: String) { mode = m; vm.clearAuthMessages() }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            when (mode) {
                "signup" -> tr("নতুন অ্যাকাউন্ট খুলুন", "Create your account")
                "forgot" -> tr("পাসওয়ার্ড ভুলে গেছেন?", "Forgot password?")
                "reset" -> tr("নতুন পাসওয়ার্ড দিন", "Set a new password")
                else -> tr("লগইন করুন", "Log in")
            },
            fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 12.dp)
        )
        OutlinedTextField(
            value = email, onValueChange = { email = it }, singleLine = true,
            label = { Text(tr("ইমেইল", "Email")) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        if (mode == "reset") {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = code, onValueChange = { code = it }, singleLine = true,
                label = { Text(tr("ইমেইলে পাওয়া কোড", "Code from your email")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (mode != "forgot") {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = pw, onValueChange = { pw = it }, singleLine = true,
                label = { Text(if (mode == "reset") tr("নতুন পাসওয়ার্ড", "New password") else tr("পাসওয়ার্ড", "Password")) },
                visualTransformation = if (showPw) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = { TextButton(onClick = { showPw = !showPw }) { Text(if (showPw) tr("লুকান", "Hide") else tr("দেখুন", "Show")) } },
                modifier = Modifier.fillMaxWidth()
            )
        }
        vm.authError?.let {
            Text(friendly(it), color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center)
        }
        when (vm.authInfo) {
            "confirm" -> Text(
                tr("আপনার ইমেইলে যাচাইয়ের লিংক পাঠানো হয়েছে। লিংকে চাপ দিয়ে এসে লগইন করুন।", "A confirmation link was sent to your email. Confirm, then log in."),
                color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center
            )
            "reset_sent" -> Text(
                tr("ইমেইলে কোড পাঠানো হয়েছে। কোড ও নতুন পাসওয়ার্ড দিন।", "A code was emailed. Enter it with your new password."),
                color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                when (mode) {
                    "signup" -> vm.signUp(email, pw)
                    "forgot" -> vm.requestReset(email)
                    "reset" -> vm.confirmReset(email, code, pw)
                    else -> vm.signIn(email, pw)
                }
            },
            enabled = !vm.authBusy && email.isNotBlank() && when (mode) {
                "forgot" -> true
                "reset" -> code.length >= 6 && pw.length >= 6
                else -> pw.length >= 6
            },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            if (vm.authBusy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            else Text(
                when (mode) {
                    "signup" -> tr("অ্যাকাউন্ট খুলুন", "Sign up")
                    "forgot" -> tr("কোড পাঠান", "Send code")
                    "reset" -> tr("পাসওয়ার্ড বদলান", "Change password")
                    else -> tr("লগইন", "Log in")
                }
            )
        }
        if (mode == "login") TextButton(onClick = { go("forgot") }) { Text(tr("পাসওয়ার্ড ভুলে গেছেন?", "Forgot password?")) }
        if (mode == "login" || mode == "signup") {
            TextButton(onClick = { go(if (mode == "signup") "login" else "signup") }) {
                Text(if (mode == "signup") tr("আগে থেকেই অ্যাকাউন্ট আছে? লগইন", "Have an account? Log in") else tr("অ্যাকাউন্ট নেই? নতুন খুলুন", "No account? Sign up"))
            }
            if (Config.GOOGLE_WEB_CLIENT_ID.isNotBlank()) {
                Text(tr("অথবা", "or"), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 4.dp))
                OutlinedButton(
                    onClick = { ctx.findActivity()?.let { vm.signInWithGoogle(it) } },
                    enabled = !vm.authBusy,
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) { Text(tr("Google দিয়ে চালিয়ে যান", "Continue with Google")) }
            }
        } else {
            TextButton(onClick = { go("login") }) { Text(tr("লগইনে ফিরুন", "Back to log in")) }
        }
    }
}

// ---------- main with bottom navigation ----------

@Composable
fun MainScreen(vm: StoreViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val selected = vm.storeApps.firstOrNull { it.id == selectedId }

    BackHandler(enabled = selectedId != null) { selectedId = null }

    if (selected != null) {
        DetailScreen(selected) { selectedId = null }
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Filled.Home, null) }, label = { Text(tr("হোম", "Home")) })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Filled.Search, null) }, label = { Text(tr("সার্চ", "Search")) })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Filled.Person, null) }, label = { Text(tr("অ্যাকাউন্ট", "Account")) })
                if (vm.profile?.isAdmin == true) NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Filled.Settings, null) }, label = { Text(tr("অ্যাডমিন", "Admin")) })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab(vm) { selectedId = it.id }
                1 -> SearchTab(vm) { selectedId = it.id }
                3 -> AdminHost(vm)
                else -> AccountTab(vm)
            }
        }
    }
}

@Composable
private fun UpdateCard(vm: StoreViewModel) {
    val u = vm.update ?: return
    Column(
        Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp)
    ) {
        Text(tr("নতুন ভার্সন পাওয়া গেছে: ", "New version available: ") + u.versionName, fontWeight = FontWeight.Bold)
        if (u.notes.isNotBlank()) Text(u.notes.take(300), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        val prog = vm.updateProgress
        if (prog != null) {
            LinearProgressIndicator(progress = prog / 100f, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
            Text("$prog%", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        vm.updateMsg?.let {
            Text(updateText(it), color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Button(onClick = { vm.installUpdate() }, enabled = prog == null, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Text(tr("আপডেট করুন", "Update now"))
        }
    }
}

private fun updateText(code: String): String = when (code) {
    "latest" -> tr("আপনি সর্বশেষ ভার্সন ব্যবহার করছেন।", "You are on the latest version.")
    "permission" -> tr("সেটিংসে এই অ্যাপকে অনুমতি দিন, তারপর ফিরে এসে আবার \"আপডেট করুন\" চাপুন।", "Allow installs for this app in Settings, come back and tap Update again.")
    else -> tr("আপডেট করা যায়নি। ইন্টারনেট দেখে আবার চেষ্টা করুন।", "Update failed. Check your connection and try again.")
}

@Composable
internal fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 8.dp))
}

@Composable
private fun AppRow(app: StoreApp, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(app, 56.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(app.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(app.developer + "  •  " + app.category, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val v = app.latest
            if (v != null) Text("v" + v.versionName + "  •  " + fmtSize(v.sizeBytes), fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
private fun FeatureCard(app: StoreApp, onClick: () -> Unit) {
    Column(
        Modifier.width(120.dp).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app, 96.dp)
        Text(app.name, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text(app.category, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun HomeTab(vm: StoreViewModel, onOpen: (StoreApp) -> Unit) {
    var cat by rememberSaveable { mutableStateOf<String?>(null) }
    val cats = vm.storeApps.map { it.category }.distinct()
    val list = vm.storeApps.filter { cat == null || it.category == cat }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(34.dp))
                Spacer(Modifier.width(10.dp))
                Text("ARMAN APP STORE", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.loadAll() }) { Icon(Icons.Filled.Refresh, tr("রিফ্রেশ", "Refresh")) }
            }
        }
        if (vm.update != null) item { UpdateCard(vm) }
        if (cats.isNotEmpty()) {
            item {
                LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = cat == null, onClick = { cat = null }, label = { Text(tr("সব", "All")) }) }
                    items(cats) { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) }
                }
            }
        }
        if (vm.loading && vm.storeApps.isEmpty()) {
            item { Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        }
        vm.loadError?.let {
            item { Text(friendly(it), color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        }
        if (!vm.loading && vm.storeApps.isEmpty() && vm.loadError == null) {
            item {
                Text(
                    tr("এখনও কোনো অ্যাপ নেই। অ্যাডমিন অ্যাপ যোগ করলে এখানে দেখা যাবে।", "No apps yet. Apps added by the admin will appear here."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp)
                )
            }
        }
        if (cat == null && vm.storeApps.isNotEmpty()) {
            item { SectionTitle(tr("নতুন ও আপডেট", "New & updated")) }
            item {
                LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp)) {
                    items(vm.storeApps.take(8), key = { it.id }) { a -> FeatureCard(a) { onOpen(a) } }
                }
            }
        }
        if (list.isNotEmpty()) {
            item { SectionTitle(tr("সব অ্যাপ", "All apps")) }
            items(list, key = { it.id }) { a -> AppRow(a) { onOpen(a) } }
        }
    }
}

@Composable
private fun SearchTab(vm: StoreViewModel, onOpen: (StoreApp) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    val words = q.lowercase().trim().split(" ").filter { it.isNotEmpty() }
    val results = if (words.isEmpty()) emptyList() else vm.storeApps.filter { a ->
        val hay = (a.name + " " + a.category + " " + a.developer).lowercase()
        words.all { hay.contains(it) }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text(tr("অ্যাপ, ক্যাটাগরি বা ডেভেলপার খুঁজুন", "Search apps, categories, developers")) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            shape = RoundedCornerShape(28.dp)
        )
        when {
            words.isEmpty() -> Text(tr("খোঁজা শুরু করুন।", "Start typing to search."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
            results.isEmpty() -> Text(tr("কোনো অ্যাপ পাওয়া যায়নি।", "No apps found."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
            else -> LazyColumn { items(results, key = { it.id }) { a -> AppRow(a) { onOpen(a) } } }
        }
    }
}

@Composable
private fun AccountTab(vm: StoreViewModel) {
    val p = vm.profile
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text(tr("অ্যাকাউন্ট", "Account"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        if (vm.session == null) {
            Text(
                tr("লগইন ছাড়াই অ্যাপ দেখা ও ডাউনলোড করা যায়। চাইলে এখানে লগইন করতে পারেন।", "You can browse and download without logging in. Log in here if you want."),
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 16.dp)
            )
            AuthForm(vm)
        } else {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
                Text(p?.email ?: vm.session?.email ?: "", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (p?.isAdmin == true) tr("ভূমিকা: অ্যাডমিন", "Role: Admin") else tr("ভূমিকা: ইউজার", "Role: User"),
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(tr("ভাষা", "Language"), fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = Lang.bn, onClick = { vm.setBengali(true) }, label = { Text("বাংলা") })
            FilterChip(selected = !Lang.bn, onClick = { vm.setBengali(false) }, label = { Text("English") })
        }
        if (vm.session != null) {
            Spacer(Modifier.height(24.dp))
            OutlinedButton(onClick = { vm.signOut() }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Text(tr("লগ আউট", "Log out"))
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(tr("অ্যাপ আপডেট", "App update"), fontWeight = FontWeight.SemiBold)
        Text("ARMAN APP STORE v" + vm.currentVersion, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
        if (vm.update != null) {
            UpdateCard(vm)
        } else {
            OutlinedButton(onClick = { vm.checkUpdate(true) }, enabled = !vm.checking, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(48.dp)) {
                Text(if (vm.checking) tr("খোঁজা হচ্ছে…", "Checking…") else tr("আপডেট খুঁজুন", "Check for updates"))
            }
            vm.updateMsg?.let { Text(updateText(it), fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 8.dp)) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ---------- details ----------

@Composable
fun DetailScreen(app: StoreApp, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val v = app.latest
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("পেছনে", "Back")) }
        }
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(app, 88.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(app.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(app.developer, color = MaterialTheme.colorScheme.secondary)
                Text(app.category, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            InfoBox(tr("ভার্সন", "Version"), v?.versionName ?: "—")
            InfoBox(tr("সাইজ", "Size"), fmtSize(v?.sizeBytes))
            InfoBox(tr("আপডেট", "Updated"), app.updatedAt.take(10).ifBlank { "—" })
        }
        Spacer(Modifier.height(18.dp))
        if (v != null) {
            Button(
                onClick = {
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(v.apkUrl))) } catch (e: ActivityNotFoundException) { }
                },
                modifier = Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(50.dp)
            ) { Text(tr("ডাউনলোড APK", "Download APK")) }
        } else {
            Text(tr("এই অ্যাপের কোনো ভার্সন এখনও আপলোড হয়নি।", "No version has been uploaded for this app yet."), modifier = Modifier.padding(horizontal = 20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (app.description.isNotBlank()) {
            SectionTitle(tr("এই অ্যাপ সম্পর্কে", "About this app"))
            Text(app.description, modifier = Modifier.padding(horizontal = 16.dp))
        }
        if (!v?.changelog.isNullOrBlank()) {
            SectionTitle(tr("নতুন কী আছে", "What's new"))
            Text(v?.changelog ?: "", modifier = Modifier.padding(horizontal = 16.dp))
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun InfoBox(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
