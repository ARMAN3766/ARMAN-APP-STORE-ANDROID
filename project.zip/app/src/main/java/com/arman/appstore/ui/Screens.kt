@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.arman.appstore.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.arman.appstore.R
import com.arman.appstore.data.Config
import com.arman.appstore.data.StoreApp
import com.arman.appstore.data.Updater

// ---------- helpers ----------

internal fun friendly(raw: String?): String {
    val m = raw ?: return ""
    return when {
        m == "network" -> tr("ইন্টারনেট সংযোগ পাওয়া যায়নি। আবার চেষ্টা করুন।", "No internet connection. Try again.")
        m == "google_fail" -> tr("Google দিয়ে লগইন হয়নি। আবার চেষ্টা করুন।", "Google sign-in failed. Please try again.")
        m.contains("expired or is invalid", true) -> tr("কোডটি ভুল অথবা মেয়াদ শেষ। নতুন কোড নিন।", "The code is wrong or expired. Request a new one.")
        m.contains("different from the old", true) -> tr("নতুন পাসওয়ার্ড আগেরটার থেকে আলাদা হতে হবে।", "The new password must differ from the old one.")
        m.contains("Invalid login", true) -> tr("ইমেইল বা পাসওয়ার্ড ভুল।", "Wrong email or password.")
        m.contains("already registered", true) -> tr("এই ইমেইল দিয়ে আগেই অ্যাকাউন্ট আছে। লগইন করুন।", "This email is already registered. Please log in.")
        m.contains("Password should", true) -> tr("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।", "Password must be at least 6 characters.")
        m.contains("Email not confirmed", true) -> tr("ইমেইল এখনও যাচাই হয়নি।", "Email is not confirmed yet.")
        m.contains("exceeded", true) || m.contains("too large", true) -> tr("ফাইল খুব বড় (সর্বোচ্চ ৫০MB)। বদলে APK-র লিংক দিন।", "File too large (50MB max). Use an APK link instead.")
        m.contains("row-level security", true) || m.contains("Unauthorized", true) -> tr("এই কাজের অনুমতি নেই। অ্যাডমিন অ্যাকাউন্টে লগইন করুন।", "Not allowed. Log in with the admin account.")
        m.contains("rate limit", true) -> tr("অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।", "Too many tries. Please wait and try again.")
        else -> m
    }
}

private fun fmtSize(b: Long?): String {
    if (b == null || b <= 0) return "—"
    val mb = b / 1048576.0
    return if (mb >= 1) String.format("%.1f MB", mb) else String.format("%.0f KB", b / 1024.0)
}

@Composable
internal fun AppIcon(app: StoreApp, size: Dp) {
    val shape = RoundedCornerShape(size / 4)
    if (app.iconUrl.isNullOrBlank()) {
        Box(
            Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text(app.name.take(1).uppercase(), fontSize = (size.value / 2.2).sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        }
    } else {
        AsyncImage(
            model = app.iconUrl, contentDescription = app.name, contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)
        )
    }
}

// ---------- root ----------

@Composable
fun AppRoot(vm: StoreViewModel) {
    Surface(
        Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        if (vm.booting) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(96.dp))
            }
        } else {
            MainScreen(vm)
        }
    }
}

// ---------- auth (inside the Account tab; browsing never needs login) ----------

internal fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun AuthForm(vm: StoreViewModel) {
    var email by rememberSaveable { mutableStateOf("") }
    var pw by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var showPw by rememberSaveable { mutableStateOf(false) }
    var mode by rememberSaveable { mutableStateOf("login") }
    val ctx = LocalContext.current

    LaunchedEffect(vm.authInfo) { if (vm.authInfo == "reset_sent") mode = "reset" }
    fun go(m: String) { mode = m; vm.clearAuthMessages() }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        if (Config.GOOGLE_WEB_CLIENT_ID.isNotBlank() && (mode == "login" || mode == "signup")) {
            OutlinedButton(
                onClick = { ctx.findActivity()?.let { vm.signInWithGoogle(it) } },
                enabled = !vm.authBusy,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(tr("Google দিয়ে চালিয়ে যান", "Continue with Google"), fontWeight = FontWeight.SemiBold) }
            Text(tr("অথবা ইমেইল দিয়ে", "or use email"), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 12.dp))
        }
        Text(
            when (mode) {
                "signup" -> tr("নতুন অ্যাকাউন্ট খুলুন", "Create your account")
                "forgot" -> tr("পাসওয়ার্ড ভুলে গেছেন?", "Forgot password?")
                "reset" -> tr("নতুন পাসওয়ার্ড দিন", "Set a new password")
                else -> tr("লগইন করুন", "Log in")
            },
            fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 12.dp)
        )
        OutlinedTextField(
            value = email, onValueChange = { email = it }, singleLine = true,
            label = { Text(tr("ইমেইল", "Email")) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        if (mode == "reset") {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = code, onValueChange = { code = it }, singleLine = true,
                label = { Text(tr("ইমেইলে পাওয়া কোড", "Code from your email")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (mode != "forgot") {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = pw, onValueChange = { pw = it }, singleLine = true,
                label = { Text(if (mode == "reset") tr("নতুন পাসওয়ার্ড", "New password") else tr("পাসওয়ার্ড", "Password")) },
                visualTransformation = if (showPw) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = { TextButton(onClick = { showPw = !showPw }) { Text(if (showPw) tr("লুকান", "Hide") else tr("দেখুন", "Show")) } },
                modifier = Modifier.fillMaxWidth()
            )
        }
        vm.authError?.let {
            Text(friendly(it), color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center)
        }
        when (vm.authInfo) {
            "confirm" -> Text(
                tr("আপনার ইমেইলে যাচাইয়ের লিংক পাঠানো হয়েছে। লিংকে চাপ দিয়ে এসে লগইন করুন।", "A confirmation link was sent to your email. Confirm, then log in."),
                color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center
            )
            "reset_sent" -> Text(
                tr("ইমেইলে কোড পাঠানো হয়েছে। কোড ও নতুন পাসওয়ার্ড দিন।", "A code was emailed. Enter it with your new password."),
                color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 10.dp), textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                when (mode) {
                    "signup" -> vm.signUp(email, pw)
                    "forgot" -> vm.requestReset(email)
                    "reset" -> vm.confirmReset(email, code, pw)
                    else -> vm.signIn(email, pw)
                }
            },
            enabled = !vm.authBusy && email.isNotBlank() && when (mode) {
                "forgot" -> true
                "reset" -> code.length >= 6 && pw.length >= 6
                else -> pw.length >= 6
            },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            if (vm.authBusy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            else Text(
                when (mode) {
                    "signup" -> tr("অ্যাকাউন্ট খুলুন", "Sign up")
                    "forgot" -> tr("কোড পাঠান", "Send code")
                    "reset" -> tr("পাসওয়ার্ড বদলান", "Change password")
                    else -> tr("লগইন", "Log in")
                }
            )
        }
        if (mode == "login") TextButton(onClick = { go("forgot") }) { Text(tr("পাসওয়ার্ড ভুলে গেছেন?", "Forgot password?")) }
        if (mode == "login" || mode == "signup") {
            TextButton(onClick = { go(if (mode == "signup") "login" else "signup") }) {
                Text(if (mode == "signup") tr("আগে থেকেই অ্যাকাউন্ট আছে? লগইন", "Have an account? Log in") else tr("অ্যাকাউন্ট নেই? নতুন খুলুন", "No account? Sign up"))
            }
        } else {
            TextButton(onClick = { go("login") }) { Text(tr("লগইনে ফিরুন", "Back to log in")) }
        }
    }
}

// ---------- shared list pieces ----------

@Composable
internal fun SectionTitle(text: String) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 8.dp))
}

@Composable
internal fun AppRow(app: StoreApp, trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(app, 56.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(app.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(app.developer + "  •  " + app.category, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val v = app.latest
            if (v != null) Text("v" + v.versionName + "  •  " + fmtSize(v.sizeBytes), fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
private fun pillColors() = ButtonDefaults.buttonColors(
    containerColor = MaterialTheme.colorScheme.primary,
    contentColor = MaterialTheme.colorScheme.onPrimary
)

/** Play Store style Install / Update / Open pill shown next to every app. */
@Composable
internal fun InstallPill(vm: StoreViewModel, app: StoreApp) {
    val ctx = LocalContext.current
    val v = app.latest ?: return
    val iv = if (app.packageName.isNotBlank()) vm.installed[app.packageName] else null
    val needs = iv != null && Updater.isNewer(v.versionName, iv)
    if (vm.installingId == app.id) {
        Text((vm.installProgress ?: 0).toString() + "%", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
    } else if (iv == null || needs) {
        Button(onClick = { vm.installApp(app) }, colors = pillColors(), contentPadding = PaddingValues(horizontal = 18.dp), modifier = Modifier.height(36.dp)) {
            Text(if (needs) tr("আপডেট", "Update") else tr("ইনস্টল", "Install"), fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    } else {
        OutlinedButton(
            onClick = { ctx.packageManager.getLaunchIntentForPackage(app.packageName)?.let { ctx.startActivity(it) } },
            contentPadding = PaddingValues(horizontal = 18.dp), modifier = Modifier.height(36.dp)
        ) { Text(tr("খুলুন", "Open"), fontSize = 14.sp) }
    }
}

@Composable
private fun FeatureCard(app: StoreApp, onClick: () -> Unit) {
    Column(
        Modifier.width(120.dp).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app, 96.dp)
        Text(app.name, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text(app.category, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
internal fun UpdateCard(vm: StoreViewModel) {
    val u = vm.update ?: return
    Column(
        Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp)
    ) {
        Text(tr("স্টোরের নতুন ভার্সন পাওয়া গেছে: ", "Store update available: ") + u.versionName, fontWeight = FontWeight.Bold)
        if (u.notes.isNotBlank()) Text(u.notes.take(300), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        val prog = vm.updateProgress
        if (prog != null) {
            LinearProgressIndicator(progress = prog / 100f, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
            Text("$prog%", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        vm.updateMsg?.let {
            Text(updateText(it), color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Button(onClick = { vm.installUpdate() }, enabled = prog == null, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Text(tr("আপডেট করুন", "Update now"))
        }
    }
}

internal fun updateText(code: String): String = when (code) {
    "latest" -> tr("আপনি সর্বশেষ ভার্সন ব্যবহার করছেন।", "You are on the latest version.")
    "permission" -> tr("একবার \"এই উৎস থেকে অনুমতি\" চালু করে ফিরে এসে আবার চাপুন। এটা শুধু প্রথমবারই লাগবে।", "Turn on \"Allow from this source\" once, come back and tap again. This is needed only the first time.")
    "queued" -> tr("ডাউনলোড শুরু হয়েছে। শেষ হলে একে একে ইনস্টল হবে, অ্যাপ বন্ধ থাকলেও চলবে।", "Downloads started. They will install one by one, even if the app is closed.")
    else -> tr("সম্পন্ন করা যায়নি। ইন্টারনেট দেখে আবার চেষ্টা করুন।", "Could not finish. Check your connection and try again.")
}

// ---------- Apps / Games tab ----------

@Composable
internal fun StoreTab(vm: StoreViewModel, games: Boolean, onOpen: (StoreApp) -> Unit) {
    val base = vm.storeApps.filter { it.category.equals("games", true) == games }
    var cat by rememberSaveable(games) { mutableStateOf<String?>(null) }
    val cats = base.map { it.category }.distinct()
    val list = base.filter { cat == null || it.category == cat }

    LazyColumn(Modifier.fillMaxSize()) {
        if (!games && vm.update != null) item { UpdateCard(vm) }
        if (cats.size > 1) {
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(selected = cat == null, onClick = { cat = null }, label = { Text(tr("সব", "All")) }) }
                    items(cats) { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) }
                }
            }
        }
        if (vm.loading && vm.apps.isEmpty()) {
            item { Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        }
        vm.loadError?.let {
            item { Text(friendly(it), color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        }
        if (!vm.loading && base.isEmpty() && vm.loadError == null) {
            item {
                Text(
                    if (games) tr("এখনও কোনো গেম নেই।", "No games yet.") else tr("এখনও কোনো অ্যাপ নেই। অ্যাডমিন অ্যাপ যোগ করলে এখানে দেখা যাবে।", "No apps yet. Apps added by the admin will appear here."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp)
                )
            }
        }
        if (cat == null && base.isNotEmpty()) {
            item { SectionTitle(tr("নতুন ও আপডেট", "New & updated")) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    items(base.take(8), key = { it.id }) { a -> FeatureCard(a) { onOpen(a) } }
                }
            }
        }
        if (list.isNotEmpty()) {
            item { SectionTitle(if (games) tr("সব গেম", "All games") else tr("সব অ্যাপ", "All apps")) }
            items(list, key = { it.id }) { a -> AppRow(a, trailing = { InstallPill(vm, a) }) { onOpen(a) } }
        }
    }
}

@Composable
internal fun SearchTab(vm: StoreViewModel, onOpen: (StoreApp) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    val words = q.lowercase().trim().split(" ").filter { it.isNotEmpty() }
    val results = if (words.isEmpty()) emptyList() else vm.storeApps.filter { a ->
        val hay = (a.name + " " + a.category + " " + a.developer).lowercase()
        words.all { hay.contains(it) }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text(tr("অ্যাপ, ক্যাটাগরি বা ডেভেলপার খুঁজুন", "Search apps, categories, developers")) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            shape = RoundedCornerShape(28.dp)
        )
        when {
            words.isEmpty() -> Text(tr("খোঁজা শুরু করুন।", "Start typing to search."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
            results.isEmpty() -> Text(tr("কোনো অ্যাপ পাওয়া যায়নি।", "No apps found."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
            else -> LazyColumn { items(results, key = { it.id }) { a -> AppRow(a, trailing = { InstallPill(vm, a) }) { onOpen(a) } } }
        }
    }
}

// ---------- details (Play Store style) ----------

@Composable
fun DetailScreen(vm: StoreViewModel, app: StoreApp, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val v = app.latest
    val installedVer = if (app.packageName.isNotBlank()) vm.installed[app.packageName] else null
    val busy = vm.installingId == app.id
    var expanded by rememberSaveable(app.id) { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("পেছনে", "Back")) }
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text(app.developer, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
            Text(app.name, fontSize = 32.sp, lineHeight = 38.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Row(Modifier.padding(20.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(app, 68.dp)
            Spacer(Modifier.width(16.dp))
            StatCol(fmtSize(v?.sizeBytes), tr("সাইজ", "Size"))
            StatDivider()
            StatCol(v?.versionName ?: "—", tr("ভার্সন", "Version"))
            StatDivider()
            StatCol(app.category, tr("ক্যাটাগরি", "Category"))
        }
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (v == null) {
                Text(tr("এই অ্যাপের কোনো ভার্সন এখনও আপলোড হয়নি।", "No version has been uploaded for this app yet."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val needsUpdate = installedVer != null && Updater.isNewer(v.versionName, installedVer)
                if (busy) {
                    Text(tr("ডাউনলোড হচ্ছে… ", "Downloading… ") + (vm.installProgress?.let { "$it%" } ?: ""))
                    LinearProgressIndicator(progress = (vm.installProgress ?: 0) / 100f, modifier = Modifier.fillMaxWidth())
                } else if (installedVer == null || needsUpdate) {
                    Button(onClick = { vm.installApp(app) }, colors = pillColors(), modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Text(if (needsUpdate) tr("আপডেট", "Update") else tr("ইনস্টল", "Install"), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.packageName))) },
                            modifier = Modifier.weight(1f).height(52.dp)
                        ) { Text(tr("আনইনস্টল", "Uninstall")) }
                        Button(
                            onClick = { ctx.packageManager.getLaunchIntentForPackage(app.packageName)?.let { ctx.startActivity(it) } },
                            colors = pillColors(), modifier = Modifier.weight(1f).height(52.dp)
                        ) { Text(tr("খুলুন", "Open"), fontWeight = FontWeight.Medium) }
                    }
                }
                vm.installMsg?.let { Text(updateText(it), color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp) }
            }
        }
        if (app.screenshots.isNotEmpty()) {
            Spacer(Modifier.height(18.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(app.screenshots) { u ->
                    AsyncImage(
                        model = u, contentDescription = app.name, contentScale = ContentScale.Crop,
                        modifier = Modifier.height(320.dp).width(180.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(horizontal = 20.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (app.category.equals("games", true)) tr("এই গেম সম্পর্কে", "About this game") else tr("এই অ্যাপ সম্পর্কে", "About this app"),
                fontSize = 20.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)
            )
            Text(if (expanded) "↑" else "→", fontSize = 22.sp)
        }
        if (app.description.isNotBlank()) {
            Text(
                app.description, maxLines = if (expanded) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }
        if (!v?.changelog.isNullOrBlank()) {
            SectionTitle(tr("নতুন কী আছে", "What's new"))
            Text(v?.changelog ?: "", modifier = Modifier.padding(horizontal = 20.dp))
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun StatCol(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 8.dp)) {
        Text(value, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun StatDivider() {
    Box(Modifier.width(1.dp).height(30.dp).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)))
}
