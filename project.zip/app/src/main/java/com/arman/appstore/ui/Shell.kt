@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.arman.appstore.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arman.appstore.R
import com.arman.appstore.data.StoreApp
import java.text.DateFormat
import java.util.Date

// ---------- shell: top bar, bottom bar (Games | Apps | Search | Admin), pages ----------

@Composable
fun MainScreen(vm: StoreViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(1) }
    var page by rememberSaveable { mutableStateOf("home") }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val selected = vm.apps.firstOrNull { it.id == selectedId }

    BackHandler(enabled = selectedId != null || page != "home") {
        if (selectedId != null) selectedId = null else page = "home"
    }
    LaunchedEffect(vm.session) { if (vm.session != null && page == "login") page = "home" }

    val open: (StoreApp) -> Unit = { selectedId = it.id }
    val back: () -> Unit = { page = "home" }

    when {
        selected != null -> DetailScreen(vm, selected) { selectedId = null }
        page == "login" -> LoginPage(vm, back)
        page == "account" -> AccountPage(vm, { page = it }, back)
        page == "notifications" -> NotificationsPage(vm, back, open)
        page == "myapps" -> MyAppsPage(vm, { page = it }, back, open)
        page == "protect" -> ProtectPage(vm, back)
        page == "settings" -> SettingsPage(vm, back)
        else -> Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopBar(
                    vm,
                    onBell = { page = "notifications" },
                    onAvatar = { page = if (vm.session == null) "login" else "account" }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Filled.PlayArrow, null) }, label = { Text(tr("গেমস", "Games")) })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Filled.Home, null) }, label = { Text(tr("অ্যাপস", "Apps")) })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Filled.Search, null) }, label = { Text(tr("সার্চ", "Search")) })
                    if (vm.profile?.isAdmin == true) {
                        NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Filled.Settings, null) }, label = { Text(tr("অ্যাডমিন", "Admin")) })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> StoreTab(vm, true, open)
                    2 -> SearchTab(vm, open)
                    3 -> if (vm.profile?.isAdmin == true) AdminHost(vm) else StoreTab(vm, false, open)
                    else -> StoreTab(vm, false, open)
                }
            }
        }
    }
}

@Composable
private fun TopBar(vm: StoreViewModel, onBell: () -> Unit, onAvatar: () -> Unit) {
    val badge = vm.updatable.size + (if (vm.update != null) 1 else 0)
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(38.dp))
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onBell) {
            if (badge > 0) BadgedBox(badge = { Badge { Text("$badge") } }) { Icon(Icons.Filled.Notifications, tr("নোটিফিকেশন", "Notifications")) }
            else Icon(Icons.Filled.Notifications, tr("নোটিফিকেশন", "Notifications"))
        }
        Spacer(Modifier.width(4.dp))
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).clickable(onClick = onAvatar),
            contentAlignment = Alignment.Center
        ) {
            val email = vm.session?.email.orEmpty()
            if (email.isNotEmpty()) Text(email.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
            else Icon(Icons.Filled.Person, tr("লগইন", "Log in"), tint = MaterialTheme.colorScheme.onPrimary)
        }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("পেছনে", "Back")) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavRow(label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f))
        Text("›", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Spacer(Modifier.height(8.dp))
}

// ---------- pages ----------

@Composable
private fun LoginPage(vm: StoreViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        PageHeader(tr("লগইন", "Log in"), onBack)
        Spacer(Modifier.height(8.dp))
        AuthForm(vm)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun AccountPage(vm: StoreViewModel, go: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val p = vm.profile
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageHeader(tr("অ্যাকাউন্ট", "Account"), onBack)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                Text((p?.email ?: vm.session?.email ?: "?").take(1).uppercase(), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(p?.email ?: vm.session?.email ?: "", fontWeight = FontWeight.SemiBold)
                Text(
                    if (p?.isAdmin == true) tr("ভূমিকা: অ্যাডমিন", "Role: Admin") else tr("ভূমিকা: ইউজার", "Role: User"),
                    color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        NavRow(tr("Google অ্যাকাউন্ট ম্যানেজ করুন", "Manage your Google Account")) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://myaccount.google.com")))
        }
        NavRow(tr("আমার অ্যাপ ও গেমস", "My apps & games")) { go("myapps") }
        NavRow(tr("নোটিফিকেশন", "Notifications")) { go("notifications") }
        NavRow(tr("অ্যাপ প্রোটেক্ট", "App Protect")) { go("protect") }
        NavRow(tr("সেটিংস", "Settings")) { go("settings") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { vm.signOut(); onBack() }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
            Text(tr("লগ আউট", "Log out"))
        }
    }
}

@Composable
private fun NotificationsPage(vm: StoreViewModel, onBack: () -> Unit, onOpen: (StoreApp) -> Unit) {
    val items = vm.storeApps.sortedByDescending { it.updatedAt }.take(30)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { PageHeader(tr("নোটিফিকেশন", "Notifications"), onBack) }
        if (vm.update != null) item { UpdateCard(vm) }
        if (items.isEmpty()) item { Text(tr("এখনও কোনো খবর নেই।", "Nothing new yet."), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp)) }
        items(items, key = { it.id }) { a ->
            Column(Modifier.fillMaxWidth().clickable { onOpen(a) }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(a.name + (a.latest?.let { "  •  v" + it.versionName } ?: ""), fontWeight = FontWeight.SemiBold)
                Text(a.updatedAt.take(10), fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                val log = a.latest?.changelog
                if (!log.isNullOrBlank()) Text(log.take(160), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

private fun gb(bytes: Long): String = String.format("%.1f GB", bytes / 1073741824.0)

@Composable
private fun MyAppsPage(vm: StoreViewModel, go: (String) -> Unit, onBack: () -> Unit, onOpen: (StoreApp) -> Unit) {
    val ctx = LocalContext.current
    var sub by rememberSaveable { mutableStateOf("overview") }
    LaunchedEffect(Unit) {
        vm.refreshInstalled()
        if (vm.scan == null) vm.runScan(false)
    }
    val st = StatFs(Environment.getDataDirectory().path)
    val total = st.blockCountLong * st.blockSizeLong
    val free = st.availableBlocksLong * st.blockSizeLong
    val used = total - free

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageHeader(tr("আমার অ্যাপ ও গেমস", "My apps & games"), onBack)
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = sub == "overview", onClick = { sub = "overview" }, label = { Text(tr("ওভারভিউ", "Overview")) })
            FilterChip(selected = sub == "manage", onClick = { sub = "manage" }, label = { Text(tr("ম্যানেজ", "Manage")) })
        }
        if (sub == "overview") {
            val sc = vm.scan
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).clickable { go("protect") }.padding(16.dp)) {
                Text(
                    when {
                        sc == null -> tr("স্ক্যান হচ্ছে…", "Scanning…")
                        sc.flagged.isEmpty() -> tr("কোনো ক্ষতিকর অ্যাপ পাওয়া যায়নি", "No harmful apps found")
                        else -> sc.flagged.size.toString() + tr(" টি অ্যাপে নজর দেওয়া দরকার", " app(s) need attention")
                    },
                    fontWeight = FontWeight.SemiBold
                )
                if (sc != null) Text(tr("সর্বশেষ স্ক্যান: ", "Last scan: ") + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(sc.timeMillis)), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
                Text(tr("আপডেট পাওয়া যাচ্ছে", "Updates available"), fontWeight = FontWeight.SemiBold)
                Text(vm.updatable.size.toString() + tr(" টি আপডেট বাকি", " update(s) pending"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (vm.updatable.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { vm.updateAll() }) { Text(tr("সব আপডেট", "Update all")) }
                        TextButton(onClick = { sub = "manage" }) { Text(tr("বিস্তারিত দেখুন", "See details")) }
                    }
                }
                vm.installMsg?.let { Text(updateText(it), fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 6.dp)) }
            }
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp)) {
                Text(gb(used) + tr(" ব্যবহৃত, মোট ", " used of ") + gb(total), fontWeight = FontWeight.SemiBold)
                LinearProgressIndicator(progress = if (total > 0) used.toFloat() / total.toFloat() else 0f, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                Text(tr("খালি: ", "Free: ") + gb(free), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { go("protect") }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Text(tr("ফোনে সমস্যা বা ম্যালওয়্যার স্ক্যান", "Scan phone for problems"))
            }
        } else {
            val inst = vm.apps.filter { it.packageName.isNotBlank() && vm.installed.containsKey(it.packageName) }
            Text(tr("এই স্টোর থেকে ইনস্টল করা", "Installed from this store"), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp, bottom = 4.dp))
            if (inst.isEmpty()) Text(tr("কোনো অ্যাপ ইনস্টল করা নেই।", "No apps installed."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            for (a in inst) {
                AppRow(a) { onOpen(a) }
                Row(Modifier.padding(start = 86.dp)) {
                    if (vm.updatable.any { it.id == a.id }) Button(onClick = { vm.installApp(a) }) { Text(tr("আপডেট", "Update")) }
                    else TextButton(onClick = { ctx.packageManager.getLaunchIntentForPackage(a.packageName)?.let { ctx.startActivity(it) } }) { Text(tr("খুলুন", "Open")) }
                    TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.packageName))) }) { Text(tr("আনইনস্টল", "Uninstall")) }
                }
            }
            Text(tr("আগে ইনস্টল বা ডাউনলোড করা", "Previously installed or downloaded"), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 20.dp, bottom = 4.dp))
            if (vm.session == null) {
                Text(tr("লগইন করলে আপনার আগের ইনস্টল ও আনইনস্টল করা অ্যাপের তালিকা সব ডিভাইসে দেখা যাবে।", "Log in to see your install and uninstall history on every device."), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val last = vm.history.distinctBy { it.appId }
                if (last.isEmpty()) Text(tr("এখনও কোনো ইতিহাস নেই।", "No history yet."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                for (h in last) {
                    val app = vm.apps.firstOrNull { it.id == h.appId }
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(h.appName, fontWeight = FontWeight.Medium)
                            Text(
                                when (h.action) {
                                    "uninstall" -> tr("আনইনস্টল করা হয়েছে", "Uninstalled")
                                    "install" -> tr("ইনস্টল করা হয়েছিল", "Installed")
                                    else -> tr("ডাউনলোড করা হয়েছিল", "Downloaded")
                                } + "  •  " + h.createdAt.take(10),
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (app != null && !vm.installed.containsKey(app.packageName)) {
                            OutlinedButton(onClick = { vm.installApp(app) }) { Text(tr("ইনস্টল", "Install")) }
                        }
                    }
                }
            }
        }
    }
}

private fun reasonText(code: String): String = when (code) {
    "a11y" -> tr("অ্যাক্সেসিবিলিটি সার্ভিস", "accessibility service")
    "overlay" -> tr("অন্য অ্যাপের ওপর ভেসে থাকার অনুমতি", "draw-over-apps permission")
    "sms" -> tr("SMS পড়া/পাঠানোর অনুমতি", "SMS permission")
    else -> tr("অন্য অ্যাপ ইনস্টলের অনুমতি", "can install other apps")
}

@Composable
private fun ProtectPage(vm: StoreViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val sc = vm.scan
    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.runScan(true) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageHeader(tr("অ্যাপ প্রোটেক্ট", "App Protect"), onBack)
        Spacer(Modifier.height(8.dp))
        Text(
            when {
                vm.scanning -> tr("স্ক্যান চলছে…", "Scanning…")
                sc == null -> tr("এখনও স্ক্যান হয়নি।", "Not scanned yet.")
                sc.flagged.isEmpty() -> tr("কোনো ক্ষতিকর অ্যাপ পাওয়া যায়নি (", "No harmful apps found (") + sc.total + tr(" টি অ্যাপ দেখা হয়েছে)", " apps checked)")
                else -> sc.flagged.size.toString() + tr(" টি অ্যাপে নজর দেওয়া দরকার", " app(s) need attention")
            },
            fontSize = 18.sp, fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.runScan(true)
            },
            enabled = !vm.scanning,
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text(tr("এখন স্ক্যান করুন", "Scan now")) }
        sc?.flagged?.forEach { f ->
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp)) {
                Text(f.label, fontWeight = FontWeight.SemiBold)
                Text(
                    if (f.high) tr("উচ্চ ঝুঁকি", "High risk") else tr("মাঝারি ঝুঁকি", "Medium risk"),
                    color = if (f.high) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary, fontSize = 12.sp
                )
                Text(f.reasons.joinToString(", ") { reasonText(it) }, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + f.pkg))) }) { Text(tr("আনইনস্টল", "Uninstall")) }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(
            tr(
                "এটি অনুমতি-ভিত্তিক প্রাথমিক পরীক্ষা, পূর্ণ অ্যান্টিভাইরাস নয়। সব সন্দেহজনক অ্যাপ ধরা নাও পড়তে পারে।",
                "This is a basic permission-based check, not a full antivirus. It may miss some threats."
            ),
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SettingsPage(vm: StoreViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageHeader(tr("সেটিংস", "Settings"), onBack)
        Spacer(Modifier.height(12.dp))
        Text(tr("ভাষা", "Language"), fontWeight = FontWeight.SemiBold)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = Lang.bn, onClick = { vm.setBengali(true) }, label = { Text("বাংলা") })
            FilterChip(selected = !Lang.bn, onClick = { vm.setBengali(false) }, label = { Text("English") })
        }
        Spacer(Modifier.height(24.dp))
        Text(tr("স্টোর আপডেট", "Store update"), fontWeight = FontWeight.SemiBold)
        Text("ARMAN APP STORE v" + vm.currentVersion, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
        if (vm.update != null) {
            UpdateCard(vm)
        } else {
            OutlinedButton(onClick = { vm.checkUpdate(true) }, enabled = !vm.checking, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(48.dp)) {
                Text(if (vm.checking) tr("খোঁজা হচ্ছে…", "Checking…") else tr("আপডেট খুঁজুন", "Check for updates"))
            }
            vm.updateMsg?.let { Text(updateText(it), fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 8.dp)) }
        }
    }
}
