package com.arman.appstore.ui

import android.app.Activity
import android.app.Application
import android.app.DownloadManager
import android.content.pm.PackageManager
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arman.appstore.data.Api
import com.arman.appstore.data.ApiException
import com.arman.appstore.data.Downloads
import com.arman.appstore.data.GoogleAuth
import com.arman.appstore.data.HistoryItem
import com.arman.appstore.data.Notifier
import com.arman.appstore.data.ScanResult
import com.arman.appstore.data.Scanner
import com.arman.appstore.data.Profile
import com.arman.appstore.data.SessionStore
import com.arman.appstore.data.StoreApp
import com.arman.appstore.data.UpdateInfo
import com.arman.appstore.data.Updater
import com.arman.appstore.data.UserSession
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

class StoreViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SessionStore(app)

    var booting by mutableStateOf(true); private set
    var session by mutableStateOf<UserSession?>(null); private set
    var profile by mutableStateOf<Profile?>(null); private set
    var apps by mutableStateOf<List<StoreApp>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var loadError by mutableStateOf<String?>(null); private set
    var authBusy by mutableStateOf(false); private set
    var authError by mutableStateOf<String?>(null); private set
    var authInfo by mutableStateOf<String?>(null); private set

    var adminBusy by mutableStateOf(false); private set
    var adminProgress by mutableStateOf<Int?>(null); private set
    var adminStatus by mutableStateOf<String?>(null); private set
    var adminError by mutableStateOf<String?>(null); private set
    var adminDone by mutableStateOf(false); private set
    val storeApps: List<StoreApp> get() = apps.filter { it.published }

    var installed by mutableStateOf<Map<String, String>>(emptyMap()); private set
    var history by mutableStateOf<List<HistoryItem>>(emptyList()); private set
    var scan by mutableStateOf<ScanResult?>(null); private set
    var scanning by mutableStateOf(false); private set
    var installingId by mutableStateOf<String?>(null); private set
    var installProgress by mutableStateOf<Int?>(null); private set
    var installMsg by mutableStateOf<String?>(null); private set
    val updatable: List<StoreApp>
        get() = apps.filter { a ->
            val iv = installed[a.packageName]
            val lv = a.latest?.versionName
            a.published && iv != null && lv != null && Updater.isNewer(lv, iv)
        }

    var update by mutableStateOf<UpdateInfo?>(null); private set
    var updateProgress by mutableStateOf<Int?>(null); private set
    var updateMsg by mutableStateOf<String?>(null); private set
    var checking by mutableStateOf(false); private set
    private var pendingApk: File? = null

    val currentVersion: String get() = Updater.currentVersion(getApplication())

    init {
        Lang.bn = store.loadBn()
        viewModelScope.launch { restore() }
        checkUpdate(false)
    }

    fun checkUpdate(manual: Boolean) {
        viewModelScope.launch {
            checking = true
            updateMsg = null
            try {
                update = Updater.check(getApplication())
                if (manual && update == null) updateMsg = "latest"
            } catch (e: Exception) {
                if (manual) updateMsg = "error"
            }
            checking = false
        }
    }

    fun installUpdate() {
        val info = update ?: return
        val ctx = getApplication<Application>()
        updateMsg = null
        if (!Updater.canInstall(ctx)) {
            Updater.openInstallSettings(ctx)
            updateMsg = "permission"
            return
        }
        val id = Downloads.enqueue(ctx, info.apkUrl, "ARMAN-APP-STORE-" + info.versionName + ".apk", "ARMAN APP STORE " + info.versionName)
        track(id, null, true)
    }

    // ---------- admin actions (the database itself refuses these for non-admins) ----------

    fun clearAdminDone() { adminDone = false }
    fun clearAdminError() { adminError = null }

    private fun admin(block: suspend (String) -> Unit) {
        if (profile?.isAdmin != true) return
        viewModelScope.launch {
            adminBusy = true; adminError = null; adminProgress = null; adminStatus = null
            try {
                val t = freshToken() ?: throw IllegalStateException("session")
                block(t)
                loadAll()
                adminDone = true
            } catch (e: ApiException) {
                adminError = e.message
            } catch (e: IOException) {
                adminError = "network"
            } catch (e: Exception) {
                adminError = e.message ?: "error"
            }
            adminBusy = false; adminProgress = null; adminStatus = null
        }
    }

    private suspend fun resolveApk(t: String, appName: String, version: String, uri: Uri?, url: String): Pair<String, Long?> {
        val ctx = getApplication<Application>()
        if (uri != null) {
            val (fname, size) = Api.fileInfo(ctx, uri)
            if (!fname.lowercase().endsWith(".apk")) throw IllegalArgumentException("bad_apk")
            adminStatus = "upload_apk"
            val path = Api.slugify(appName) + "/v" + Api.slugify(version) + "-" + System.currentTimeMillis() + ".apk"
            val u = Api.upload(ctx, t, "apks", path, uri, "application/vnd.android.package-archive", size) { adminProgress = it }
            return u to (if (size > 0) size else null)
        }
        val clean = url.trim()
        if (!clean.startsWith("https://")) throw IllegalArgumentException("need_apk")
        return clean to null
    }

    private suspend fun resolveIcon(t: String, appName: String, uri: Uri?): String? {
        if (uri == null) return null
        val ctx = getApplication<Application>()
        val (_, size) = Api.fileInfo(ctx, uri)
        val mime = ctx.contentResolver.getType(uri) ?: "image/png"
        val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else if (mime.contains("webp")) "webp" else "png"
        adminStatus = "upload_icon"
        adminProgress = null
        return Api.upload(ctx, t, "icons", Api.slugify(appName) + "-" + System.currentTimeMillis() + "." + ext, uri, mime, size) { }
    }

    private suspend fun resolveShots(t: String, appName: String, uris: List<Uri>): JSONArray? {
        if (uris.isEmpty()) return null
        val ctx = getApplication<Application>()
        val arr = JSONArray()
        uris.forEachIndexed { i, u ->
            val (_, size) = Api.fileInfo(ctx, u)
            val mime = ctx.contentResolver.getType(u) ?: "image/png"
            val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else if (mime.contains("webp")) "webp" else "png"
            adminStatus = "upload_shots"
            adminProgress = null
            arr.put(Api.upload(ctx, t, "icons", "shots/" + Api.slugify(appName) + "-" + System.currentTimeMillis() + "-" + i + "." + ext, u, mime, size) { })
        }
        return arr
    }

    fun createApp(name: String, dev: String, cat: String, pkg: String, desc: String, icon: Uri?, version: String, changelog: String, apk: Uri?, apkUrl: String, shots: List<Uri> = emptyList()) =
        admin { t ->
            if (name.isBlank()) throw IllegalArgumentException("need_name")
            if (version.isBlank()) throw IllegalArgumentException("need_version")
            val (url, size) = resolveApk(t, name, version, apk, apkUrl)
            val iconUrl = resolveIcon(t, name, icon)
            val shotArr = resolveShots(t, name, shots)
            adminStatus = "saving"
            val id = Api.createApp(t, name.trim(), dev.trim(), cat.trim().ifBlank { "Tools" }, pkg.trim(), desc.trim(), iconUrl, shotArr)
            Api.addVersion(t, id, version.trim(), url, size, changelog.trim())
        }

    fun saveInfo(app: StoreApp, name: String, dev: String, cat: String, pkg: String, desc: String, icon: Uri?, shots: List<Uri> = emptyList()) =
        admin { t ->
            if (name.isBlank()) throw IllegalArgumentException("need_name")
            val iconUrl = resolveIcon(t, name, icon)
            adminStatus = "saving"
            val f = JSONObject().put("name", name.trim()).put("developer", dev.trim())
                .put("category", cat.trim().ifBlank { "Tools" }).put("description", desc.trim()).put("package_name", pkg.trim())
            if (iconUrl != null) f.put("icon_url", iconUrl)
            resolveShots(t, name, shots)?.let { f.put("screenshots", it) }
            Api.updateApp(t, app.id, f)
        }

    fun addVersion(app: StoreApp, version: String, changelog: String, apk: Uri?, apkUrl: String) =
        admin { t ->
            if (version.isBlank()) throw IllegalArgumentException("need_version")
            val (url, size) = resolveApk(t, app.name, version, apk, apkUrl)
            adminStatus = "saving"
            Api.addVersion(t, app.id, version.trim(), url, size, changelog.trim())
        }

    fun setPublished(id: String, value: Boolean) = admin { t -> Api.updateApp(t, id, JSONObject().put("is_published", value)) }

    fun deleteApp(id: String) = admin { t -> Api.deleteApp(t, id) }

    // ---------- installed apps, history, install, scan ----------

    private fun record(app: StoreApp, action: String) {
        if (session == null) return
        viewModelScope.launch {
            try {
                val t = freshToken() ?: return@launch
                Api.addHistory(t, app.id, app.latest?.id, action)
                refreshHistory()
            } catch (e: Exception) {
                // history is optional; ignore failures
            }
        }
    }

    fun refreshHistory() {
        if (session == null) return
        viewModelScope.launch {
            try {
                val t = freshToken() ?: return@launch
                history = Api.fetchHistory(t)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun refreshInstalled() {
        if (apps.isEmpty()) return
        val pm = getApplication<Application>().packageManager
        val map = mutableMapOf<String, String>()
        for (a in apps) {
            if (a.packageName.isBlank()) continue
            try {
                map[a.packageName] = pm.getPackageInfo(a.packageName, 0).versionName ?: ""
            } catch (e: PackageManager.NameNotFoundException) {
                // not installed
            }
        }
        installed = map
        val prev = store.loadInstalled()
        if (prev != null && session != null) {
            for (pkg in map.keys - prev) apps.firstOrNull { it.packageName == pkg }?.let { record(it, "install") }
            for (pkg in prev - map.keys) apps.firstOrNull { it.packageName == pkg }?.let { record(it, "uninstall") }
        }
        store.saveInstalled(map.keys)
    }

    private fun track(id: Long, appId: String?, self: Boolean) {
        viewModelScope.launch {
            val dm = getApplication<Application>().getSystemService(DownloadManager::class.java)
            if (appId != null) { installingId = appId; installProgress = 0 }
            if (self) updateProgress = 0
            while (true) {
                var done = false
                dm.query(DownloadManager.Query().setFilterById(id)).use { c ->
                    if (c != null && c.moveToFirst()) {
                        val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        if (total > 0) {
                            val pr = (got * 100 / total).toInt()
                            if (appId != null) installProgress = pr
                            if (self) updateProgress = pr
                        }
                        if (st == DownloadManager.STATUS_SUCCESSFUL) done = true
                        if (st == DownloadManager.STATUS_FAILED) { done = true; installMsg = "error"; updateMsg = "error" }
                    } else {
                        done = true
                    }
                }
                if (done) break
                delay(700)
            }
            if (appId != null) { installingId = null; installProgress = null }
            if (self) updateProgress = null
        }
    }

    private fun fileName(app: StoreApp, v: com.arman.appstore.data.AppVersion) =
        Api.slugify(app.name) + "-" + Api.slugify(v.versionName) + ".apk"

    fun installApp(app: StoreApp) {
        val v = app.latest ?: return
        val ctx = getApplication<Application>()
        installMsg = null
        if (!Updater.canInstall(ctx)) {
            Updater.openInstallSettings(ctx)
            installMsg = "permission"
            return
        }
        val id = Downloads.enqueue(ctx, v.apkUrl, fileName(app, v), app.name + " " + v.versionName)
        record(app, "download")
        track(id, app.id, false)
    }

    fun updateAll() {
        val ctx = getApplication<Application>()
        val list = updatable
        if (list.isEmpty()) return
        installMsg = null
        if (!Updater.canInstall(ctx)) {
            Updater.openInstallSettings(ctx)
            installMsg = "permission"
            return
        }
        for (a in list) {
            val v = a.latest ?: continue
            Downloads.enqueue(ctx, v.apkUrl, fileName(a, v), a.name + " " + v.versionName)
            record(a, "download")
        }
        installMsg = "queued"
    }

    fun runScan(notify: Boolean) {
        viewModelScope.launch {
            scanning = true
            val ctx = getApplication<Application>()
            val r = withContext(Dispatchers.Default) { Scanner.scan(ctx) }
            scan = r
            scanning = false
            if (notify && r.flagged.isNotEmpty()) Notifier.threats(ctx, r.flagged.size)
        }
    }

    fun setBengali(v: Boolean) {
        Lang.bn = v
        store.saveBn(v)
    }
}
