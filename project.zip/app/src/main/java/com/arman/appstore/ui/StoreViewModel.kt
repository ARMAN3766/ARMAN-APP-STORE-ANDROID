package com.arman.appstore.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arman.appstore.data.Api
import com.arman.appstore.data.ApiException
import com.arman.appstore.data.Profile
import com.arman.appstore.data.SessionStore
import com.arman.appstore.data.StoreApp
import com.arman.appstore.data.UpdateInfo
import com.arman.appstore.data.Updater
import com.arman.appstore.data.UserSession
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.io.IOException

class StoreViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SessionStore(app)

    var booting by mutableStateOf(true); private set
    var session by mutableStateOf<UserSession?>(null); private set
    var profile by mutableStateOf<Profile?>(null); private set
    var apps by mutableStateOf<List<StoreApp>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var loadError by mutableStateOf<String?>(null); private set
    var authBusy by mutableStateOf(false); private set
    var authError by mutableStateOf<String?>(null); private set
    var authInfo by mutableStateOf<String?>(null); private set

    var adminBusy by mutableStateOf(false); private set
    var adminProgress by mutableStateOf<Int?>(null); private set
    var adminStatus by mutableStateOf<String?>(null); private set
    var adminError by mutableStateOf<String?>(null); private set
    var adminDone by mutableStateOf(false); private set
    val storeApps: List<StoreApp> get() = apps.filter { it.published }

    var update by mutableStateOf<UpdateInfo?>(null); private set
    var updateProgress by mutableStateOf<Int?>(null); private set
    var updateMsg by mutableStateOf<String?>(null); private set
    var checking by mutableStateOf(false); private set
    private var pendingApk: File? = null

    val currentVersion: String get() = Updater.currentVersion(getApplication())

    init {
        Lang.bn = store.loadBn()
        viewModelScope.launch { restore() }
        checkUpdate(false)
    }

    fun checkUpdate(manual: Boolean) {
        viewModelScope.launch {
            checking = true
            updateMsg = null
            try {
                update = Updater.check(getApplication())
                if (manual && update == null) updateMsg = "latest"
            } catch (e: Exception) {
                if (manual) updateMsg = "error"
            }
            checking = false
        }
    }

    fun installUpdate() {
        val info = update ?: return
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            updateMsg = null
            try {
                var file = pendingApk
                if (file == null || !file.exists()) {
                    updateProgress = 0
                    file = Updater.download(ctx, info) { updateProgress = it }
                    pendingApk = file
                }
                updateProgress = null
                if (!Updater.install(ctx, file)) updateMsg = "permission"
            } catch (e: Exception) {
                updateProgress = null
                updateMsg = "error"
            }
        }
    }

    private fun nowSec() = System.currentTimeMillis() / 1000

    private fun adopt(s: UserSession) {
        session = s
        store.save(s)
    }

    private suspend fun restore() {
        val saved = store.load()
        if (saved != null) {
            try {
                adopt(if (saved.expiresAtSec - nowSec() < 60) Api.refresh(saved.refreshToken) else saved)
            } catch (e: ApiException) {
                store.clear()
            } catch (e: IOException) {
                session = saved
            }
        }
        booting = false
        if (session != null) loadAll()
    }

    private suspend fun freshToken(): String? {
        var s = session ?: return null
        if (s.expiresAtSec - nowSec() < 60) {
            try {
                s = Api.refresh(s.refreshToken)
                adopt(s)
            } catch (e: ApiException) {
                signOut()
                return null
            }
        }
        return s.accessToken
    }

    fun loadAll() {
        viewModelScope.launch {
            loading = true
            loadError = null
            try {
                val t = freshToken()
                val s = session
                if (t != null && s != null) {
                    val pr = Api.fetchProfile(t, s)
                    profile = pr
                    apps = Api.fetchApps(t, pr.isAdmin)
                }
            } catch (e: ApiException) {
                loadError = e.message
            } catch (e: IOException) {
                loadError = "network"
            }
            loading = false
        }
    }

    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                adopt(Api.signIn(email.trim(), password))
                loadAll()
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            }
            authBusy = false
        }
    }

    fun signUp(email: String, password: String) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                val s = Api.signUp(email.trim(), password)
                if (s != null) { adopt(s); loadAll() } else authInfo = "confirm"
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            }
            authBusy = false
        }
    }

    fun signOut() {
        store.clear()
        session = null
        profile = null
        apps = emptyList()
    }

    // ---------- admin actions (the database itself refuses these for non-admins) ----------

    fun clearAdminDone() { adminDone = false }
    fun clearAdminError() { adminError = null }

    private fun admin(block: suspend (String) -> Unit) {
        if (profile?.isAdmin != true) return
        viewModelScope.launch {
            adminBusy = true; adminError = null; adminProgress = null; adminStatus = null
            try {
                val t = freshToken() ?: throw IllegalStateException("session")
                block(t)
                loadAll()
                adminDone = true
            } catch (e: ApiException) {
                adminError = e.message
            } catch (e: IOException) {
                adminError = "network"
            } catch (e: Exception) {
                adminError = e.message ?: "error"
            }
            adminBusy = false; adminProgress = null; adminStatus = null
        }
    }

    private suspend fun resolveApk(t: String, appName: String, version: String, uri: Uri?, url: String): Pair<String, Long?> {
        val ctx = getApplication<Application>()
        if (uri != null) {
            val (fname, size) = Api.fileInfo(ctx, uri)
            if (!fname.lowercase().endsWith(".apk")) throw IllegalArgumentException("bad_apk")
            adminStatus = "upload_apk"
            val path = Api.slugify(appName) + "/v" + Api.slugify(version) + "-" + System.currentTimeMillis() + ".apk"
            val u = Api.upload(ctx, t, "apks", path, uri, "application/vnd.android.package-archive", size) { adminProgress = it }
            return u to (if (size > 0) size else null)
        }
        val clean = url.trim()
        if (!clean.startsWith("https://")) throw IllegalArgumentException("need_apk")
        return clean to null
    }

    private suspend fun resolveIcon(t: String, appName: String, uri: Uri?): String? {
        if (uri == null) return null
        val ctx = getApplication<Application>()
        val (_, size) = Api.fileInfo(ctx, uri)
        val mime = ctx.contentResolver.getType(uri) ?: "image/png"
        val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else if (mime.contains("webp")) "webp" else "png"
        adminStatus = "upload_icon"
        adminProgress = null
        return Api.upload(ctx, t, "icons", Api.slugify(appName) + "-" + System.currentTimeMillis() + "." + ext, uri, mime, size) { }
    }

    fun createApp(name: String, dev: String, cat: String, desc: String, icon: Uri?, version: String, changelog: String, apk: Uri?, apkUrl: String) =
        admin { t ->
            if (name.isBlank()) throw IllegalArgumentException("need_name")
            if (version.isBlank()) throw IllegalArgumentException("need_version")
            val (url, size) = resolveApk(t, name, version, apk, apkUrl)
            val iconUrl = resolveIcon(t, name, icon)
            adminStatus = "saving"
            val id = Api.createApp(t, name.trim(), dev.trim(), cat.trim().ifBlank { "Tools" }, desc.trim(), iconUrl)
            Api.addVersion(t, id, version.trim(), url, size, changelog.trim())
        }

    fun saveInfo(app: StoreApp, name: String, dev: String, cat: String, desc: String, icon: Uri?) =
        admin { t ->
            if (name.isBlank()) throw IllegalArgumentException("need_name")
            val iconUrl = resolveIcon(t, name, icon)
            adminStatus = "saving"
            val f = JSONObject().put("name", name.trim()).put("developer", dev.trim())
                .put("category", cat.trim().ifBlank { "Tools" }).put("description", desc.trim())
            if (iconUrl != null) f.put("icon_url", iconUrl)
            Api.updateApp(t, app.id, f)
        }

    fun addVersion(app: StoreApp, version: String, changelog: String, apk: Uri?, apkUrl: String) =
        admin { t ->
            if (version.isBlank()) throw IllegalArgumentException("need_version")
            val (url, size) = resolveApk(t, app.name, version, apk, apkUrl)
            adminStatus = "saving"
            Api.addVersion(t, app.id, version.trim(), url, size, changelog.trim())
        }

    fun setPublished(id: String, value: Boolean) = admin { t -> Api.updateApp(t, id, JSONObject().put("is_published", value)) }

    fun deleteApp(id: String) = admin { t -> Api.deleteApp(t, id) }

    fun setBengali(v: Boolean) {
        Lang.bn = v
        store.saveBn(v)
    }
}
