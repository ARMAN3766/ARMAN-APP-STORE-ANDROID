package com.arman.appstore.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arman.appstore.data.Api
import com.arman.appstore.data.ApiException
import com.arman.appstore.data.Profile
import com.arman.appstore.data.SessionStore
import com.arman.appstore.data.StoreApp
import com.arman.appstore.data.UserSession
import kotlinx.coroutines.launch
import java.io.IOException

class StoreViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SessionStore(app)

    var booting by mutableStateOf(true); private set
    var session by mutableStateOf<UserSession?>(null); private set
    var profile by mutableStateOf<Profile?>(null); private set
    var apps by mutableStateOf<List<StoreApp>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var loadError by mutableStateOf<String?>(null); private set
    var authBusy by mutableStateOf(false); private set
    var authError by mutableStateOf<String?>(null); private set
    var authInfo by mutableStateOf<String?>(null); private set

    init {
        Lang.bn = store.loadBn()
        viewModelScope.launch { restore() }
    }

    private fun nowSec() = System.currentTimeMillis() / 1000

    private fun adopt(s: UserSession) {
        session = s
        store.save(s)
    }

    private suspend fun restore() {
        val saved = store.load()
        if (saved != null) {
            try {
                adopt(if (saved.expiresAtSec - nowSec() < 60) Api.refresh(saved.refreshToken) else saved)
            } catch (e: ApiException) {
                store.clear()
            } catch (e: IOException) {
                session = saved
            }
        }
        booting = false
        if (session != null) loadAll()
    }

    private suspend fun freshToken(): String? {
        var s = session ?: return null
        if (s.expiresAtSec - nowSec() < 60) {
            try {
                s = Api.refresh(s.refreshToken)
                adopt(s)
            } catch (e: ApiException) {
                signOut()
                return null
            }
        }
        return s.accessToken
    }

    fun loadAll() {
        viewModelScope.launch {
            loading = true
            loadError = null
            try {
                val t = freshToken()
                val s = session
                if (t != null && s != null) {
                    profile = Api.fetchProfile(t, s)
                    apps = Api.fetchApps(t)
                }
            } catch (e: ApiException) {
                loadError = e.message
            } catch (e: IOException) {
                loadError = "network"
            }
            loading = false
        }
    }

    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                adopt(Api.signIn(email.trim(), password))
                loadAll()
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            }
            authBusy = false
        }
    }

    fun signUp(email: String, password: String) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                val s = Api.signUp(email.trim(), password)
                if (s != null) { adopt(s); loadAll() } else authInfo = "confirm"
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            }
            authBusy = false
        }
    }

    fun signOut() {
        store.clear()
        session = null
        profile = null
        apps = emptyList()
    }

    fun setBengali(v: Boolean) {
        Lang.bn = v
        store.saveBn(v)
    }
}
