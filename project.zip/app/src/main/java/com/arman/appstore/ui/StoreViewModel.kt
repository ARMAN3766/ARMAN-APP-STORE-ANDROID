package com.arman.appstore.ui

import android.app.Activity
import android.app.Application
import android.app.DownloadManager
import android.content.pm.PackageManager
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arman.appstore.data.Api
import com.arman.appstore.data.ApiException
import com.arman.appstore.data.DeviceApp
import com.arman.appstore.data.DlTask
import com.arman.appstore.data.DownloadCenter
import com.arman.appstore.data.PackageTools
import com.arman.appstore.data.busy
import com.arman.appstore.data.GoogleAuth
import com.arman.appstore.data.HistoryItem
import com.arman.appstore.data.Notifier
import com.arman.appstore.data.ScanResult
import com.arman.appstore.data.Scanner
import com.arman.appstore.data.Profile
import com.arman.appstore.data.SessionStore
import com.arman.appstore.data.StoreApp
import com.arman.appstore.data.UpdateInfo
import com.arman.appstore.data.Updater
import com.arman.appstore.data.UserSession
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

class StoreViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SessionStore(app)

    var booting by mutableStateOf(true); private set
    var session by mutableStateOf<UserSession?>(null); private set
    var profile by mutableStateOf<Profile?>(null); private set
    var apps by mutableStateOf<List<StoreApp>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var loadError by mutableStateOf<String?>(null); private set
    var authBusy by mutableStateOf(false); private set
    var authError by mutableStateOf<String?>(null); private set
    var authInfo by mutableStateOf<String?>(null); private set

    var adminBusy by mutableStateOf(false); private set
    var adminProgress by mutableStateOf<Int?>(null); private set
    var adminStatus by mutableStateOf<String?>(null); private set
    var adminError by mutableStateOf<String?>(null); private set
    var adminDone by mutableStateOf(false); private set
    val storeApps: List<StoreApp> get() = apps.filter { it.published }

    var installed by mutableStateOf<Map<String, String>>(emptyMap()); private set
    var history by mutableStateOf<List<HistoryItem>>(emptyList()); private set
    var deviceApps by mutableStateOf<List<DeviceApp>>(emptyList()); private set
    var scan by mutableStateOf<ScanResult?>(null); private set
    var scanning by mutableStateOf(false); private set
    var installMsg by mutableStateOf<String?>(null); private set
    val updatable: List<StoreApp>
        get() = apps.filter { a ->
            val iv = installed[a.packageName]
            val lv = a.latest?.versionName
            a.published && iv != null && lv != null && Updater.isNewer(lv, iv)
        }

    var themeMode by mutableStateOf("system"); private set

    var update by mutableStateOf<UpdateInfo?>(null); private set
    var updateMsg by mutableStateOf<String?>(null); private set
    var checking by mutableStateOf(false); private set
    private var pendingApk: File? = null

    val currentVersion: String get() = Updater.currentVersion(getApplication())

    init {
        Lang.bn = store.loadBn()
        DownloadCenter.onChanged = { refreshInstalled(); loadDeviceApps() }
        DownloadCenter.onPackageLearned = { id, pkg -> learnPackage(id, pkg) }
        themeMode = store.loadTheme()
        viewModelScope.launch { restore() }
        checkUpdate(false)
    }

    fun checkUpdate(manual: Boolean) {
        viewModelScope.launch {
            checking = true
            updateMsg = null
            try {
                update = Updater.check(getApplication())
                if (manual && update == null) updateMsg = "latest"
            } catch (e: Exception) {
                if (manual) updateMsg = "error"
            }
            checking = false
        }
    }

    fun installUpdate() {
        val info = update ?: return
        val ctx = getApplication<Application>()
        updateMsg = null
        if (!Updater.canInstall(ctx)) {
            Updater.openInstallSettings(ctx)
            updateMsg = "permission"
            return
        }
        DownloadCenter.enqueue(
            DlTask("self", "ARMAN APP STORE", null, ctx.packageName, info.versionName, info.apkUrl, "ARMAN-APP-STORE-" + info.versionName + ".apk", true)
        )
    }

    private fun nowSec() = System.currentTimeMillis() / 1000

    private fun adopt(s: UserSession) {
        session = s
        store.save(s)
    }

    private suspend fun restore() {
        val saved = store.load()
        if (saved != null) {
            try {
                adopt(if (saved.expiresAtSec - nowSec() < 60) Api.refresh(saved.refreshToken) else saved)
            } catch (e: ApiException) {
                store.clear()
            } catch (e: IOException) {
                session = saved
            }
        }
        booting = false
        loadAll()
    }

    private suspend fun freshToken(): String? {
        var s = session ?: return null
        if (s.expiresAtSec - nowSec() < 60) {
            try {
                s = Api.refresh(s.refreshToken)
                adopt(s)
            } catch (e: ApiException) {
                signOut()
                return null
            }
        }
        return s.accessToken
    }

    fun loadAll() {
        viewModelScope.launch {
            loading = true
            loadError = null
            try {
                val t = freshToken()
                val s = session
                if (t != null && s != null) {
                    val pr = Api.fetchProfile(t, s)
                    profile = pr
                    apps = withLearned(Api.fetchApps(t, pr.isAdmin))
                    refreshHistory()
                } else {
                    profile = null
                    apps = withLearned(Api.fetchApps(null, false))
                    history = emptyList()
                }
                refreshInstalled()
            } catch (e: ApiException) {
                loadError = e.message
            } catch (e: IOException) {
                loadError = "network"
            }
            loading = false
        }
    }

    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                adopt(Api.signIn(email.trim(), password))
                loadAll()
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            }
            authBusy = false
        }
    }

    fun signUp(email: String, password: String) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                val s = Api.signUp(email.trim(), password)
                if (s != null) { adopt(s); loadAll() } else authInfo = "confirm"
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            }
            authBusy = false
        }
    }

    fun signOut() {
        store.clear()
        session = null
        profile = null
        loadAll()
    }

    fun clearAuthMessages() { authError = null; authInfo = null }

    fun requestReset(email: String) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                Api.recover(email.trim())
                authInfo = "reset_sent"
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            }
            authBusy = false
        }
    }

    fun confirmReset(email: String, code: String, newPassword: String) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                val s = Api.verifyRecovery(email.trim(), code)
                Api.updatePassword(s.accessToken, newPassword)
                adopt(s)
                loadAll()
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            }
            authBusy = false
        }
    }

    fun signInWithGoogle(activity: Activity) {
        viewModelScope.launch {
            authBusy = true; authError = null; authInfo = null
            try {
                adopt(Api.signInWithGoogle(GoogleAuth.idToken(activity)))
                loadAll()
            } catch (e: GetCredentialCancellationException) {
                // user closed the chooser
            } catch (e: GetCredentialException) {
                authError = "google_fail"
            } catch (e: ApiException) {
                authError = e.message
            } catch (e: IOException) {
                authError = "network"
            } catch (e: Exception) {
                authError = e.message ?: "error"
            }
            authBusy = false
        }
    }

    // ---------- admin actions (the database itself refuses these for non-admins) ----------

    fun clearAdminDone() { adminDone = false }
    fun clearAdminError() { adminError = null }

    private fun admin(block: suspend (String) -> Unit) {
        if (profile?.isAdmin != true) return
        viewModelScope.launch {
            adminBusy = true; adminError = null; adminProgress = null; adminStatus = null
            try {
                val t = freshToken() ?: throw IllegalStateException("session")
                block(t)
                loadAll()
                adminDone = true
            } catch (e: ApiException) {
                adminError = e.message
            } catch (e: IOException) {
                adminError = "network"
            } catch (e: Exception) {
                adminError = e.message ?: "error"
            }
            adminBusy = false; adminProgress = null; adminStatus = null
        }
    }

    private suspend fun resolveApk(t: String, appName: String, version: String, uri: Uri?, url: String): Pair<String, Long?> {
        val ctx = getApplication<Application>()
        if (uri != null) {
            val (fname, size) = Api.fileInfo(ctx, uri)
            if (!fname.lowercase().endsWith(".apk")) throw IllegalArgumentException("bad_apk")
            adminStatus = "upload_apk"
            val path = Api.slugify(appName) + "/v" + Api.slugify(version) + "-" + System.currentTimeMillis() + ".apk"
            val u = Api.upload(ctx, t, "apks", path, uri, "application/vnd.android.package-archive", size) { adminProgress = it }
            return u to (if (size > 0) size else null)
        }
        val clean = url.trim()
        if (!clean.startsWith("https://")) throw IllegalArgumentException("need_apk")
        return clean to null
    }

    private suspend fun resolveIcon(t: String, appName: String, uri: Uri?): String? {
        if (uri == null) return null
        val ctx = getApplication<Application>()
        val (_, size) = Api.fileInfo(ctx, uri)
        val mime = ctx.contentResolver.getType(uri) ?: "image/png"
        val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else if (mime.contains("webp")) "webp" else "png"
        adminStatus = "upload_icon"
        adminProgress = null
        return Api.upload(ctx, t, "icons", Api.slugify(appName) + "-" + System.currentTimeMillis() + "." + ext, uri, mime, size) { }
    }

    private suspend fun resolveShots(t: String, appName: String, uris: List<Uri>): JSONArray? {
        if (uris.isEmpty()) return null
        val ctx = getApplication<Application>()
        val arr = JSONArray()
        uris.forEachIndexed { i, u ->
            val (_, size) = Api.fileInfo(ctx, u)
            val mime = ctx.contentResolver.getType(u) ?: "image/png"
            val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else if (mime.contains("webp")) "webp" else "png"
            adminStatus = "upload_shots"
            adminProgress = null
            arr.put(Api.upload(ctx, t, "icons", "shots/" + Api.slugify(appName) + "-" + System.currentTimeMillis() + "-" + i + "." + ext, u, mime, size) { })
        }
        return arr
    }

    fun createApp(name: String, dev: String, cat: String, pkg: String, desc: String, icon: Uri?, version: String, changelog: String, apk: Uri?, apkUrl: String, shots: List<Uri> = emptyList()) =
        admin { t ->
            if (name.isBlank()) throw IllegalArgumentException("need_name")
            if (version.isBlank()) throw IllegalArgumentException("need_version")
            val (url, size) = resolveApk(t, name, version, apk, apkUrl)
            val iconUrl = resolveIcon(t, name, icon)
            val shotArr = resolveShots(t, name, shots)
            adminStatus = "saving"
            val id = Api.createApp(t, name.trim(), dev.trim(), cat.trim().ifBlank { "Tools" }, pkg.trim(), desc.trim(), iconUrl, shotArr)
            Api.addVersion(t, id, version.trim(), url, size, changelog.trim())
        }

    fun saveInfo(app: StoreApp, name: String, dev: String, cat: String, pkg: String, desc: String, icon: Uri?, shots: List<Uri> = emptyList()) =
        admin { t ->
            if (name.isBlank()) throw IllegalArgumentException("need_name")
            val iconUrl = resolveIcon(t, name, icon)
            adminStatus = "saving"
            val f = JSONObject().put("name", name.trim()).put("developer", dev.trim())
                .put("category", cat.trim().ifBlank { "Tools" }).put("description", desc.trim()).put("package_name", pkg.trim())
            if (iconUrl != null) f.put("icon_url", iconUrl)
            resolveShots(t, name, shots)?.let { f.put("screenshots", it) }
            Api.updateApp(t, app.id, f)
        }

    fun addVersion(app: StoreApp, version: String, changelog: String, apk: Uri?, apkUrl: String) =
        admin { t ->
            if (version.isBlank()) throw IllegalArgumentException("need_version")
            val (url, size) = resolveApk(t, app.name, version, apk, apkUrl)
            adminStatus = "saving"
            Api.addVersion(t, app.id, version.trim(), url, size, changelog.trim())
        }

    fun setPublished(id: String, value: Boolean) = admin { t -> Api.updateApp(t, id, JSONObject().put("is_published", value)) }

    fun deleteApp(id: String) = admin { t -> Api.deleteApp(t, id) }

    // ---------- installed apps, history, install, scan ----------

    private fun record(app: StoreApp, action: String) {
        if (session == null) return
        viewModelScope.launch {
            try {
                val t = freshToken() ?: return@launch
                Api.addHistory(t, app.id, app.latest?.id, action)
                refreshHistory()
            } catch (e: Exception) {
                // history is optional; ignore failures
            }
        }
    }

    private fun withLearned(list: List<StoreApp>): List<StoreApp> =
        list.map { a -> if (a.packageName.isBlank()) (store.learned(a.id)?.let { a.copy(packageName = it) } ?: a) else a }

    private fun learnPackage(appId: String, pkg: String) {
        store.saveLearned(appId, pkg)
        apps = apps.map { if (it.id == appId && it.packageName.isBlank()) it.copy(packageName = pkg) else it }
        if (profile?.isAdmin == true) {
            viewModelScope.launch {
                try {
                    val t = freshToken() ?: return@launch
                    Api.updateApp(t, appId, JSONObject().put("package_name", pkg))
                } catch (e: Exception) {
                    // saving the package name for everyone is optional
                }
            }
        }
        refreshInstalled()
    }

    fun loadDeviceApps() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            deviceApps = withContext(Dispatchers.Default) { PackageTools.loadDeviceApps(ctx) }
        }
    }

    fun refreshHistory() {
        if (session == null) return
        viewModelScope.launch {
            try {
                val t = freshToken() ?: return@launch
                history = Api.fetchHistory(t)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun refreshInstalled() {
        if (apps.isEmpty()) return
        val pm = getApplication<Application>().packageManager
        val map = mutableMapOf<String, String>()
        for (a in apps) {
            if (a.packageName.isBlank()) continue
            try {
                map[a.packageName] = pm.getPackageInfo(a.packageName, 0).versionName ?: ""
            } catch (e: PackageManager.NameNotFoundException) {
                // not installed
            }
        }
        installed = map
        val prev = store.loadInstalled()
        if (prev != null && session != null) {
            for (pkg in map.keys - prev) apps.firstOrNull { it.packageName == pkg }?.let { record(it, "install") }
            for (pkg in prev - map.keys) apps.firstOrNull { it.packageName == pkg }?.let { record(it, "uninstall") }
        }
        store.saveInstalled(map.keys)
    }


    private fun fileName(app: StoreApp, v: com.arman.appstore.data.AppVersion) =
        Api.slugify(app.name) + "-" + Api.slugify(v.versionName) + ".apk"

    private fun taskFor(app: StoreApp, v: com.arman.appstore.data.AppVersion, isUpdate: Boolean) =
        DlTask(app.id, app.name, app.iconUrl, app.packageName, v.versionName, v.apkUrl, fileName(app, v), isUpdate)

    fun installApp(app: StoreApp) {
        val v = app.latest ?: return
        val ctx = getApplication<Application>()
        installMsg = null
        if (!Updater.canInstall(ctx)) {
            Updater.openInstallSettings(ctx)
            installMsg = "permission"
            return
        }
        val isUpdate = installed[app.packageName]?.let { Updater.isNewer(v.versionName, it) } == true
        DownloadCenter.enqueue(taskFor(app, v, isUpdate))
        record(app, "download")
    }

    fun updateAll() {
        val ctx = getApplication<Application>()
        val list = updatable.filter { a -> DownloadCenter.find(a.id)?.state?.busy() != true }
        if (list.isEmpty()) return
        installMsg = null
        if (!Updater.canInstall(ctx)) {
            Updater.openInstallSettings(ctx)
            installMsg = "permission"
            return
        }
        for (a in list) {
            val v = a.latest ?: continue
            DownloadCenter.enqueue(taskFor(a, v, true))
            record(a, "download")
        }
        installMsg = "queued"
    }

    fun runScan(notify: Boolean) {
        viewModelScope.launch {
            scanning = true
            val ctx = getApplication<Application>()
            val r = withContext(Dispatchers.Default) { Scanner.scan(ctx) }
            scan = r
            scanning = false
            if (notify && r.flagged.isNotEmpty()) Notifier.threats(ctx, r.flagged.size)
        }
    }

    fun setTheme(mode: String) {
        themeMode = mode
        store.saveTheme(mode)
    }

    fun setBengali(v: Boolean) {
        Lang.bn = v
        store.saveBn(v)
    }
}
