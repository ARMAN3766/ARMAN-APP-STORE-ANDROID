package com.arman.appstore.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

object Lang {
    var bn by mutableStateOf(true)
}

fun tr(bn: String, en: String): String = if (Lang.bn) bn else en

// Neutral Play-Store-like palettes: clear text, soft surfaces, one blue accent.
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFA8C7FA),
    onPrimary = Color(0xFF062E6F),
    secondary = Color(0xFF8AB4F8),
    secondaryContainer = Color(0xFF004A77),
    onSecondaryContainer = Color(0xFFC2E7FF),
    background = Color(0xFF131314),
    onBackground = Color(0xFFE3E3E3),
    surface = Color(0xFF1E1F20),
    onSurface = Color(0xFFE3E3E3),
    surfaceVariant = Color(0xFF2A2B2D),
    onSurfaceVariant = Color(0xFFC4C7C5),
    outline = Color(0xFF8E918F),
    error = Color(0xFFF2B8B5)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0B57D0),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF0B57D0),
    secondaryContainer = Color(0xFFD3E3FD),
    onSecondaryContainer = Color(0xFF001D35),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF1F1F1F),
    surface = Color(0xFFF3F6FC),
    onSurface = Color(0xFF1F1F1F),
    surfaceVariant = Color(0xFFE1E7F0),
    onSurfaceVariant = Color(0xFF444746),
    outline = Color(0xFF747775),
    error = Color(0xFFB3261E)
)

@Composable
fun ArmanTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val scheme = if (dark) DarkScheme else LightScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            var c: Context = view.context
            while (c is ContextWrapper && c !is Activity) c = c.baseContext
            val w = (c as? Activity)?.window
            if (w != null) {
                w.statusBarColor = scheme.background.toArgb()
                w.navigationBarColor = scheme.background.toArgb()
                val ctl = WindowCompat.getInsetsController(w, view)
                ctl.isAppearanceLightStatusBars = !dark
                ctl.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
