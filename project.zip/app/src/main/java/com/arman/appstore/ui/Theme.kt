package com.arman.appstore.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

object Lang {
    var bn by mutableStateOf(true)
}

fun tr(bn: String, en: String): String = if (Lang.bn) bn else en

private val scheme = darkColorScheme(
    primary = Color(0xFF3B82F6),
    onPrimary = Color.White,
    secondary = Color(0xFF38BDF8),
    background = Color(0xFF050B1F),
    onBackground = Color(0xFFEAF0FF),
    surface = Color(0xFF0E1B3F),
    onSurface = Color(0xFFEAF0FF),
    surfaceVariant = Color(0xFF14264F),
    onSurfaceVariant = Color(0xFF93A3C8),
    error = Color(0xFFFF6B6B)
)

@Composable
fun ArmanTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
